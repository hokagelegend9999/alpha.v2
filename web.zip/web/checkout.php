<?php
$apiKey       = 'safEJ03IxOxRkpYp9jWMw1ylXL6FbTQDuA1Z81ma';
$privateKey   = 'y9aKf-1Qnht-MRPjN-vYAou-IAd9J';
$merchantCode = 'T45045';
$urlWebKita   = 'https://web.hokage.web.id/';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { die("Metode tidak diizinkan."); }
$paket_nama  = $_POST['nama_paket'];
$paket_harga = (int)$_POST['harga_paket'];
$telegram_id = $_POST['telegram_id'];
$method      = $_POST['method'];
$merchantRef = 'HL-' . time();

$data = [
    'method'         => $method,
    'merchant_ref'   => $merchantRef,
    'amount'         => $paket_harga,
    'customer_name'  => $telegram_id, 
    'customer_email' => 'buyer@hokage.web.id', 
    'customer_phone' => '081234567890',        
    'order_items'    => [[ 'sku' => 'VPN-01', 'name' => $paket_nama, 'price' => $paket_harga, 'quantity' => 1 ]],
    'signature'      => hash_hmac('sha256', $merchantCode.$merchantRef.$paket_harga, $privateKey)
];

$tripayEndpoint = 'https://tripay.co.id/api/transaction/create';
$curl = curl_init();
curl_setopt_array($curl, [
    CURLOPT_FRESH_CONNECT  => true, CURLOPT_URL => $tripayEndpoint, CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => ['Authorization: Bearer '.$apiKey], CURLOPT_POST => true,
    CURLOPT_POSTFIELDS     => http_build_query($data)
]);
$response = curl_exec($curl); curl_close($curl);
$result = json_decode($response);
if ($result->success) { header("Location: " . $result->data->checkout_url); } else { echo "Error: " . $result->message; }
?>
