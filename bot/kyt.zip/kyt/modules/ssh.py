from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# =================================================================
# FUNGSI PEMBANTU: AMBIL DATA & FORMAT PAGINATION
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell"""
    try:
        cmd = '/usr/bin/kyt/shell/bot/bot-member-ssh'
        if not os.path.exists(cmd):
            cmd = 'bot-member-ssh'
            
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except:
        return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    msg = f"""
<b>👑 LIST MEMBER PREMIUM SSH</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user SSH aktif.</i>\n"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]
                    exp = parts[1]
                    status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"""
👤 <b>User   :</b> <code>{user}</code>
📅 <b>Exp    :</b> <code>{exp}</code>
{icon_stat} <b>Status :</b> <code>{status}</code>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
"""
                else: continue
            except: continue

    display_page = page + 1 if total_pages > 0 else 0
    msg += f"📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

def get_vps_ip():
    try:
        return subprocess.check_output("curl -sS ipv4.icanhazip.com", shell=True).decode("utf-8").strip()
    except:
        return "Unknown"

# =================================================================
# 1. CREATE SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Akses Ditolak!", alert=True)
        return

    async def create_ssh_process():
        try:
            # 1. Input Username
            async with bot.conversation(chat, timeout=120) as user_convo:
                await event.respond('📝 **Input Username:**\n*(Ketik `/cancel` untuk batal)*')
                user_event = await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if user_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                user = user_event.raw_text
            
            # 2. Input Password
            async with bot.conversation(chat, timeout=120) as pw_convo:
                await event.respond("🔑 **Input Password:**")
                pw_event = await pw_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if pw_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                pw = pw_event.raw_text
    
            # 3. Input Limit IP
            async with bot.conversation(chat, timeout=120) as limit_convo:
                await event.respond("📱 **Input Max Login/IP Limit:**\n`Contoh: 2`")
                limit_event = await limit_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if limit_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                limit = limit_event.raw_text

            # 4. Input Quota
            async with bot.conversation(chat, timeout=120) as quota_convo:
                await event.respond("📈 **Input Quota (GB):**\n`Contoh: 10`")
                quota_event = await quota_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if quota_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                quota = quota_event.raw_text
            
            # 5. Input Expired
            async with bot.conversation(chat, timeout=120) as exp_convo:
                await event.respond("⏳ **Input Masa Aktif (Hari):**\n`Contoh: 30`")
                exp_event = await exp_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if exp_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                exp = exp_event.raw_text
        
            msg_load = await event.respond("⚙️ `Processing SSH Account...`")
            
            # --- LOGIC UTAMA ---
            # Command Linux standard
            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                
                # Format tanggal untuk Database (misal: 19 Jun, 2026)
                exp_db = later.strftime("%d %b, %Y")
                created_date = today.strftime("%d %b %Y")
                expired_date = later.strftime("%d %b %Y")
                ip_vps = get_vps_ip()

                # MEMASUKKAN DATA KE DATABASE .SSH.DB DENGAN PYTHON
                db_entry = f"#ssh# {user.strip()} {pw.strip()} {quota.strip()} {limit.strip()} {exp_db}\n"
                try:
                    with open("/etc/ssh/.ssh.db", "a") as db_file:
                        db_file.write(db_entry)
                except Exception as e:
                    print(f"Error writing to db: {e}")

                # MEMBUAT FILE TXT UNTUK DOWNLOAD LINK
                txt_content = f"""---------------------------------------------------
HOKAGE LEGEND TUNNELING
---------------------------------------------------
Format SSH OVPN Account
---------------------------------------------------
Username         : {user.strip()}
Password         : {pw.strip()}
---------------------------------------------------
IP               : {ip_vps}
Host             : {DOMAIN}
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port Dropbear WS : 443, 109
Port SSH UDP     : 1-65535
Port SSH WS      : 80, 8080, 8081-9999
Port SSH SSL WS  : 443
Port SSL/TLS     : 400-900
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 443, 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
---------------------------------------------------
Aktif Selama     : {exp} Hari
Dibuat Pada      : {created_date}
Berakhir Pada    : {expired_date}
---------------------------------------------------
Payload WSS: GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf] 
---------------------------------------------------
OVPN Download : https://{DOMAIN}:81/
---------------------------------------------------"""
                try:
                    os.makedirs("/var/www/html", exist_ok=True)
                    with open(f"/var/www/html/ssh-{user.strip()}.txt", "w") as f:
                        f.write(txt_content)
                except:
                    pass

            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("⚠️ **User Already Exist / Error System**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
            else:
                msg = f"""
<b>✨ PREMIUM ACCOUNT CREATED ✨</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username :</b> <code>{user.strip()}</code>
🔑 <b>Password :</b> <code>{pw.strip()}</code>
📈 <b>Quota    :</b> <code>{quota.strip()} GB</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 <b>IP VPS   :</b> <code>{ip_vps}</code>
🏢 <b>Host     :</b> <code>{DOMAIN}</code>

<b>⚙️ PORT SETTINGS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
🛡 <b>OpenSSH      :</b> <code>443, 80, 22</code>
🛡 <b>Dropbear     :</b> <code>443, 109</code>
🛡 <b>SSH WS       :</b> <code>80, 8080, 8081-9999</code>
🛡 <b>SSH UDP      :</b> <code>1-65535</code>
🔒 <b>SSH SSL WS   :</b> <code>443</code>
🔒 <b>SSL/TLS      :</b> <code>400-900</code>
🔒 <b>OVPN WS SSL  :</b> <code>443</code>
🔒 <b>OVPN SSL     :</b> <code>443</code>
🔒 <b>OVPN TCP     :</b> <code>443, 1194</code>
🚀 <b>OVPN UDP     :</b> <code>2200</code>
🚀 <b>BadVPN UDP   :</b> <code>7100, 7300, 7300</code>

<b>🔗 FORMAT & PAYLOAD</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>Payload WSS:</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>OVPN Config :</b> https://{DOMAIN}:81/
<b>Save Link   :</b> https://{DOMAIN}:81/ssh-{user.strip()}.txt

<b>📊 ACCOUNT DETAILS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⏳ <b>Aktif Selama :</b> <code>{exp} Hari</code>
📅 <b>Dibuat Pada  :</b> <code>{created_date}</code>
⌛ <b>Berakhir     :</b> <code>{expired_date}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Main Menu", "menu")]])

        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain berjalan! Ketik /cancel terlebih dahulu.", alert=True)
        except asyncio.TimeoutError:
            await event.respond("⌛ **Waktu Habis.**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`", buttons=[[Button.inline("🔙 Main Menu", "menu")]])

    await create_ssh_process()

# =================================================================
# 2. DELETE SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Akses Ditolak!", alert=True)
        return

    async def delete_ssh_process():
        try:
            async with bot.conversation(chat, timeout=120) as user_convo:
                await event.respond("🗑 **Username To Be Deleted:**\n*(Ketik `/cancel` untuk batal)*")
                user_event = await user_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if user_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                user = user_event.raw_text
                
            cmd = f'userdel -f {user}'
            
            try:
                subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError:
                await event.respond(f"⚠️ **User** `{user}` **Not Found in System**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
            else:
                subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
                
                # Cleanup DB & text file
                subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)
                subprocess.run(f'rm -f /var/www/html/ssh-{user}.txt', shell=True)
                
                await event.respond(f"✅ **Successfully Deleted SSH:** `{user}`", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
                
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain berjalan! Ketik /cancel terlebih dahulu.", alert=True)
        except asyncio.TimeoutError:
            await event.respond("⌛ **Timeout.**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
            
    await delete_ssh_process()

# =================================================================
# 3. TRIAL SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Akses Ditolak!", alert=True)
        return

    async def trial_ssh_process():
        try:
            async with bot.conversation(chat, timeout=60) as exp_convo:
                await event.respond("⏱ **Input Masa Aktif (Menit):**\n`Contoh: 30`\n*(Ketik `/cancel` untuk batal)*")
                exp_event = await exp_convo.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if exp_event.raw_text == '/cancel':
                    await event.respond("❌ **Proses Dibatalkan.**")
                    return
                exp = exp_event.raw_text
                if not exp.isdigit():
                     await event.respond("⚠️ **Error:** Harap masukkan angka saja.")
                     return

            user = "trialX"+str(random.randint(100,1000))
            pw = "1"
            
            msg_load = await event.respond("⚙️ `Creating Trial SSH...`")
            
            cmd_sys = f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins 1" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                today = DT.date.today()
                created_date = today.strftime("%d %b %Y")
                
                # Masukkan juga ke DB agar di VPS bisa dicek passwordnya
                db_exp_date = (today + DT.timedelta(days=1)).strftime("%d %b, %Y")
                db_entry = f"#ssh# {user} {pw} 1 1 {db_exp_date}\n"
                try:
                    with open("/etc/ssh/.ssh.db", "a") as db_file:
                        db_file.write(db_entry)
                except:
                    pass

                ip_vps = get_vps_ip()

            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("⚠️ **Failed to create trial.**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
            else:
                msg = f"""
<b>✨ TRIAL ACCOUNT CREATED ✨</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username :</b> <code>{user.strip()}</code>
🔑 <b>Password :</b> <code>{pw.strip()}</code>
📈 <b>Quota    :</b> <code>1 GB</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 <b>IP VPS   :</b> <code>{ip_vps}</code>
🏢 <b>Host     :</b> <code>{DOMAIN}</code>

<b>⚙️ PORT SETTINGS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
🛡 <b>OpenSSH      :</b> <code>443, 80, 22</code>
🛡 <b>Dropbear     :</b> <code>443, 109</code>
🛡 <b>SSH WS       :</b> <code>80, 8080, 8081-9999</code>
🛡 <b>SSH UDP      :</b> <code>1-65535</code>
🔒 <b>SSH SSL WS   :</b> <code>443</code>
🔒 <b>SSL/TLS      :</b> <code>400-900</code>
🔒 <b>OVPN WS SSL  :</b> <code>443</code>
🔒 <b>OVPN SSL     :</b> <code>443</code>
🔒 <b>OVPN TCP     :</b> <code>443, 1194</code>
🚀 <b>OVPN UDP     :</b> <code>2200</code>
🚀 <b>BadVPN UDP   :</b> <code>7100, 7300, 7300</code>

<b>🔗 FORMAT & PAYLOAD</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>Payload WSS:</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>OVPN Config :</b> https://{DOMAIN}:81/

<b>📊 ACCOUNT DETAILS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⏳ <b>Aktif Selama :</b> <code>{exp} Menit</code>
📅 <b>Dibuat Pada  :</b> <code>{created_date}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Main Menu", "menu")]])
        
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain berjalan! Ketik /cancel terlebih dahulu.", alert=True)
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`", buttons=[[Button.inline("🔙 Main Menu", "menu")]])

    await trial_ssh_process()

# =================================================================
# 4. SHOW SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return

    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, 0)
    
    buttons = []
    if total_pages > 1:
        buttons.append([Button.inline("Next ⏩", data=f"sshPage_1")])
    buttons.append([Button.inline("🔙 Main Menu", "menu")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.reply(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'sshPage_(\d+)'))
async def paginate_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return

    try: page = int(event.data.decode().split('_')[1])
    except: page = 0
    
    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, page)
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"sshPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"sshPage_{page+1}"))
    
    buttons = []
    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("🔙 Main Menu", "menu")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.answer("ℹ️ Halaman tidak berubah")

# =================================================================
# 5. LOGIN SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        try:
            cmd = 'bot-cek-login-ssh'.strip()
            z = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
            
            if len(z) > 4000:
                nama_file = "login_ssh.txt"
                with open(nama_file, "w") as f:
                    f.write(z)
                await event.client.send_file(
                    event.chat_id,
                    nama_file,
                    caption="⚠️ **List Login Terlalu Panjang!**",
                    buttons=[[Button.inline("🔙 Main Menu","menu")]]
                )
                os.remove(nama_file)
            else:
                await event.respond(f"{z}\n🔍 **Check Login SSH**", buttons=[[Button.inline("🔙 Main Menu","menu")]])
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`")

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await login_ssh_(event)
    else:
        await event.answer("⚠️ Access Denied", alert=True)

# =================================================================
# 6. MENU UTAMA SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return
        
    try:
        inline = [
            [Button.inline("⏱ TRIAL SSH", "trial-ssh"), Button.inline("✨ CREATE SSH", "create-ssh")],
            [Button.inline("🗑 DELETE SSH", "delete-ssh"), Button.inline("🔍 CHECK LOGIN", "login-ssh")],
            [Button.inline("👥 SHOW USERS", "show-ssh"), Button.inline("📝 REGIS IP", "regis")],
            [Button.inline("🔙 Main Menu", "menu")]
        ]
        try:
             isp = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()
             country = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('country', 'Unknown'))\"", shell=True).decode("utf-8").strip()
        except:
             isp = "Unknown"
             country = "Unknown"

        msg = f"""
<b>👑 HOKAGE PREMIUM TUNNELING 👑</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ <b>SSH & OVPN MANAGEMENT MENU</b> ⚡
━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 <b>System Information:</b>
🖥 <b>Service  :</b> <code>SSH & OVPN</code>
🌐 <b>Hostname :</b> <code>{DOMAIN}</code>
🏢 <b>ISP      :</b> <code>{isp}</code>
🌍 <b>Country  :</b> <code>{country}</code>

👨‍💻 <b>Dev :</b> @HookageLegend
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Silakan pilih opsi manajemen di bawah ini:</i>
"""
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"❌ Error: {str(e)}")