from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
import re
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# =================================================================
# GLOBAL STATE UNTUK CONVERSATION
# =================================================================
active_convs = {}

@bot.on(events.CallbackQuery(data=b'cancel_process'))
async def cancel_process_handler(event):
    chat = event.chat_id
    if chat in active_convs:
        active_convs[chat].cancel()
        del active_convs[chat]
    await event.edit("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

# =================================================================
# FUNGSI PEMBANTU: AMBIL DATA & FORMAT PAGINATION
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell dengan Auto-Detect Path"""
    possible_paths = [
        '/usr/bin/kyt/shell/bot/bot-member-ssh',
        '/usr/bin/kyt/shell/bot-member-ssh',
        'bot-member-ssh'
    ]
    
    cmd = None
    for path in possible_paths:
        if os.path.exists(path):
            cmd = path
            break
            
    if not cmd: return []

    try:
        subprocess.run(f"chmod +x {cmd}", shell=True)
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except:
        return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    msg = f"""
<b>☁️ LIST MEMBER SSH & VPN</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user SSH aktif saat ini.</i>"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]
                    exp = parts[1]
                    status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"""
<b>👤 User :</b> <code>{user}</code>
<b>📅 Exp  :</b> <code>{exp}</code>
<b>💎 Stat :</b> {icon_stat} <code>{status}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
                else: continue
            except: continue

    display_page = page + 1 if total_pages > 0 else 0
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

# =================================================================
# 1. CREATE SSH (TANPA ZIVPN & UDP)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async def create_ssh_process():
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            
            async with bot.conversation(chat, timeout=120) as conv:
                active_convs[chat] = conv
                
                prompt_msg = await event.respond('<b>👤 Input Username:</b>', parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                    return
                user = ev.raw_text
                await prompt_msg.edit(buttons=None)
                
                prompt_msg = await event.respond("<b>🔑 Input Password:</b>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                    return
                pw = ev.raw_text
                await prompt_msg.edit(buttons=None)

                prompt_msg = await event.respond("<b>📱 Input Max Login/IP Limit:</b>\nContoh: <code>2</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                    return
                limit = ev.raw_text
                await prompt_msg.edit(buttons=None)

                prompt_msg = await event.respond("<b>💾 Input Quota (GB):</b>\nContoh: <code>10</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                    return
                quota = ev.raw_text
                await prompt_msg.edit(buttons=None)
            
                prompt_msg = await event.respond("<b>📅 Input Masa Aktif (Hari):</b>\nContoh: <code>30</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                    return
                exp = ev.raw_text
                await prompt_msg.edit(buttons=None)
        
            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>🔄 Processing SSH Account...</code>", parse_mode='html')
            
            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("<b>⚠️ User Already Exist / Error</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
            else:
                msg = f"""
<b>✅ SSH ACCOUNT CREATED</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username :</b> <code>{user.strip()}</code>
<b>🔑 Password :</b> <code>{pw.strip()}</code>
<b>⏳ Expired  :</b> <code>{later}</code>
<b>📱 Limit IP :</b> <code>{limit.strip()} Device</code>
<b>💾 Quota    :</b> <code>{quota.strip()} GB</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔌 CONNECTION DETAILS</b>
<b>🌐 Host/IP  :</b> <code>{DOMAIN}</code>
<b>🔮 SSH SSL  :</b> <code>{DOMAIN}:443</code>
<b>🔮 SSH WS   :</b> <code>{DOMAIN}:80</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali ke Menu", "ssh")]])

        except asyncio.CancelledError:
            return
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain! Selesaikan atau batalkan dulu.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis.</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error:</b> <code>{str(e)}</code>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')

    await create_ssh_process()

# =================================================================
# 2. DELETE SSH (TANPA ZIVPN)
# =================================================================
def get_vip_details(user):
    limit_ip = "Unlimited"
    quota_info = "Unlimited"
    status_lock = "🟢 Active"

    try:
        path_limit = f"/etc/kyt/limit/ssh/ip/{user}"
        if os.path.exists(path_limit):
            with open(path_limit, 'r') as f:
                val = f.read().strip()
                if val and val != "0": limit_ip = f"{val} Device"
    except: pass

    try:
        path_quota = f"/etc/ssh/{user}"
        if os.path.exists(path_quota):
            with open(path_quota, 'r') as f:
                content = f.read().strip()
                if content.isdigit():
                    bytes_val = int(content)
                    if bytes_val > 0:
                        gb_val = bytes_val / 1073741824
                        quota_info = f"{gb_val:.2f} GB"
    except: pass

    return limit_ip, quota_info, status_lock

async def render_delete_menu(event, page):
    sender = await event.get_sender()
    data_list = get_ssh_data() 
    
    item_per_page = 5
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0

    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]

    msg = f"<b>🗑️ DELETE SSH ACCOUNT</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    buttons = []
    
    # Penampung array tombol horizontal
    number_buttons = []
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user terdaftar.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            try:
                parts = row.split("|")
                if len(parts) >= 1:
                    user = parts[0].strip()
                    try:
                        cmd_exp = f"chage -l {user} | grep 'Account expires' | cut -d: -f2"
                        exp_raw = subprocess.check_output(cmd_exp, shell=True).decode("utf-8").strip()
                        exp_date = "Unlimited" if "never" in exp_raw else exp_raw
                    except: 
                        exp_date = parts[1].strip() if len(parts) > 1 else "Unknown"

                    limit, quota, status = get_vip_details(user)
                    nomor = start + i + 1 # Perbaikan agar halaman 2 dimulai dari nomor 6
                    
                    msg += f"""<b>{nomor}. {user}</b> | {status}
   ├ 📅 Exp: <code>{exp_date}</code>
   ├ 💾 Quota: <code>{quota}</code>
   └ 📱 Limit: <code>{limit}</code>
"""
                    # Tombol berbentuk "❌ 1", "❌ 2" sejajar horizontal
                    number_buttons.append(Button.inline(f"❌ {nomor}", data=f"del_cf:{user}"))
            except: continue

    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page + 1}/{total_pages}"
    
    # Masukkan array horizontal ke kerangka tombol utama
    if number_buttons:
        buttons.append(number_buttons)
        
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"del_pg:{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"del_pg:{page+1}"))
    
    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("🔙 Kembali", "ssh")])

    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.respond(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    await render_delete_menu(event, 0)

@bot.on(events.CallbackQuery(pattern=b'del_pg:(\d+)'))
async def delete_ssh_paginate(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    try:
        page = int(event.data.decode().split(':')[1])
        await render_delete_menu(event, page)
    except: await event.answer("Error Pagination")

@bot.on(events.CallbackQuery(pattern=b'del_cf:(.*)'))
async def delete_ssh_confirm(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    user_to_del = event.data.decode().split(':')[1]

    msg = f"""
<b>❓ KONFIRMASI PENGHAPUSAN</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
Apakah Anda yakin ingin menghapus user ini?

👤 <b>User :</b> <code>{user_to_del}</code>

<i>⚠️ Data user, limit, dan quota akan dihapus permanen!</i>
"""
    buttons = [
        [Button.inline("✅ YA, HAPUS PERMANEN", data=f"del_ex:{user_to_del}")],
        [Button.inline("🔙 BATAL", data="delete-ssh")]
    ]
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'del_ex:(.*)'))
async def delete_ssh_execute(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    user = event.data.decode().split(':')[1]

    msg_load = await event.edit("<b>🔄 Processing Deletion...</b>", parse_mode='html')

    try:
        cmd = f'userdel -f {user}'
        try: subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
        except: pass 
        
        subprocess.run(f'rm -f /etc/kyt/limit/ssh/ip/{user}', shell=True)
        subprocess.run(f'rm -f /etc/ssh/{user}', shell=True)
        subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
        subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)

        await msg_load.edit(
            f"<b>✅ DELETED SUCCESSFULLY</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n👤 User <code>{user}</code> telah berhasil dihapus beserta seluruh datanya.",
            buttons=[[Button.inline("🔙 Kembali ke Menu List", "delete-ssh")]],
            parse_mode='html'
        )
    except Exception as e:
        await msg_load.edit(f"<b>❌ Error:</b> {str(e)}", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')

# =================================================================
# 3. TRIAL SSH (TANPA ZIVPN & UDP)
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return

    async def trial_ssh_process():
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            
            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv
                
                prompt_msg = await event.respond("<b>⏱️ Input Trial Time (Menit):</b>\nContoh: <code>60</code>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                    return
                exp = ev.raw_text
                await prompt_msg.edit(buttons=None)
                
                if not exp.isdigit():
                     active_convs.pop(chat, None)
                     await event.respond("<b>❌ Error: Harap masukkan angka.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                     return

            active_convs.pop(chat, None)
            
            user = "trialX"+str(random.randint(100,1000))
            pw = "1"
            
            msg_load = await event.respond("<code>🔄 Creating Trial SSH...</code>", parse_mode='html')
            
            cmd_sys = f'useradd -e "`date -d "{exp} minutes" +"%Y-%m-%d %H:%M:%S"`" -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins 1" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("<b>❌ Failed to create trial.</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
            else:
                msg = f"""
<b>✅ SSH TRIAL CREATED</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username :</b> <code>{user.strip()}</code>
<b>🔑 Password :</b> <code>{pw.strip()}</code>
<b>⏳ Expired  :</b> <code>{exp} Minutes</code>
<b>📱 Limit IP :</b> <code>1 Device</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔌 CONNECTION DETAILS</b>
<b>🌐 Host/IP  :</b> <code>{DOMAIN}</code>
<b>🔮 SSH SSL  :</b> <code>{DOMAIN}:443</code>
<b>🔮 SSH WS   :</b> <code>{DOMAIN}:80</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali ke Menu", "ssh")]])
        
        except asyncio.CancelledError:
            return
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain! Selesaikan atau batalkan dulu.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis.</b>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error:</b> <code>{str(e)}</code>", buttons=[[Button.inline("🔙 Kembali", "ssh")]], parse_mode='html')
            
    await trial_ssh_process()

# =================================================================
# 4. SHOW SSH & DETAIL AKUN (TERINTEGRASI DGN SCRIPT MEMBER)
# =================================================================
def get_full_user_detail(username):
    # 1. Ambil Info Server (Meniru bash script member)
    domain = DOMAIN if 'DOMAIN' in globals() else "IP-Only"
    try:
        with open("/etc/xray/domain", "r") as f: domain = f.read().strip()
    except: pass

    ip = "Unknown"
    try: ip = requests.get("https://ipv4.icanhazip.com", timeout=3).text.strip()
    except: pass

    udp_zivpn = "5667"
    try:
        with open("/etc/zivpn/config.json", "r") as f:
            for line in f:
                if '"listen"' in line:
                    udp_zivpn = line.split('"')[3].replace(':', '').replace('0.0.0.0', '')
                    break
    except: pass

    pub = "Not Set"
    try:
        with open("/etc/slowdns/server.pub", "r") as f: pub = f.read().strip()
    except: pass

    ns = "Not Set"
    try:
        with open("/etc/xray/dns", "r") as f: ns = f.read().strip()
    except: pass

    isp = "Unknown"
    try:
        with open("/root/.info/.isp", "r") as f: isp = f.read().strip()
    except: pass

    city = "Unknown"
    try:
        with open("/root/.info/.city", "r") as f: city = f.read().strip()
    except: pass

    # 2. Ambil Info Database User
    password, quota, iplimit = "???", "0", "0"
    exp_date_fmt = "Unknown"

    try:
        with open("/etc/ssh/.ssh.db", "r") as f:
            for line in f:
                if line.startswith(f"#ssh# {username} "):
                    parts = line.strip().split()
                    if len(parts) >= 8:
                        password = parts[2]
                        quota = parts[3]
                        iplimit = parts[4]
                        exp_date_fmt = f"{parts[5]} {parts[6]} {parts[7]}"
                    break
    except: pass

    try:
        exp_raw = subprocess.check_output(f"chage -l {username} | grep 'Account expires' | cut -d: -f2", shell=True).decode("utf-8").strip()
        if "never" in exp_raw.lower():
            exp_date_fmt = "Unlimited"
        elif exp_raw:
            dt = DT.datetime.strptime(exp_raw, "%b %d, %Y")
            exp_date_fmt = dt.strftime("%d %b, %Y")
    except: pass

    msg = f"""
<b>🔵 DETAIL AKUN SSH & ZIVPN 🔵</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>➤ Domain        :</b> <code>{domain}</code>
<b>➤ Username      :</b> <code>{username}</code>
<b>➤ Password      :</b> <code>{password}</code>
<b>➤ ZIVPN Token   :</b> <code>{username}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>➤ Limit Ip      :</b> <code>{iplimit} Device</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>➤ IP            :</b> <code>{ip}</code>
<b>➤ Limit Quota   :</b> <code>{quota} GB</code>
<b>➤ Host Slowdns  :</b> <code>{ns}</code>
<b>➤ Isp           :</b> <code>{isp}</code>
<b>➤ Location      :</b> <code>{city}</code>
<b>➤ Port OpenSSH  :</b> <code>443, 80, 22</code>
<b>➤ Port DNS      :</b> <code>443, 53, 22</code>
<b>➤ Port SSH UDP  :</b> <code>1-65535</code>
<b>➤ Port ZIVPN    :</b> <code>{udp_zivpn}</code>
<b>➤ Port Dropbear :</b> <code>443, 109</code>
<b>➤ Port SSH WS   :</b> <code>80, 8080, 8880, 2082</code>
<b>➤ Port OVPN SSL :</b> <code>443</code>
<b>➤ Port OVPN TCP :</b> <code>443, 1194</code>
<b>➤ Port OVPN UDP :</b> <code>2200</code>
<b>➤ BadVPN UDP    :</b> <code>7100, 7300, 7300</code>
<b>➤ Pub Key       :</b> <code>{pub}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>Payload Websocket :</b>
<code>GET / HTTP/1.1[crlf]host: {domain}[crlf]Upgrade: Websocket[crlf][crlf]</code>

<b>Payload SSL / TLS :</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {domain}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>OVPN Download   :</b> <code>https://{domain}:81/</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>Berakhir Pada   :</b> <code>{exp_date_fmt}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
    return msg

async def render_show_menu(event, page):
    sender = await event.get_sender()
    data_list = get_ssh_data()

    item_per_page = 5  
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0

    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]

    msg = f"<b>☁️ LIST MEMBER SSH & VPN</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    buttons = []
    
    # Menampung tombol angka agar bisa disejajarkan ke samping (horizontal)
    number_buttons = []

    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user terdaftar.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            try:
                parts = row.split("|")
                if len(parts) >= 1:
                    user = parts[0].strip()
                    exp_date = parts[1].strip() if len(parts) > 1 else "Unknown"
                    status = parts[2].strip() if len(parts) > 2 else "UNKNOWN"
                    icon_stat = "🟢" if "UNLOCKED" in status.upper() else "🔴"

                    nomor = start + i + 1

                    msg += f"<b>{nomor}. User:</b> <code>{user}</code>\n"
                    msg += f"   ├ 📅 Exp: <code>{exp_date}</code>\n"
                    msg += f"   └ 💎 Stat: {icon_stat} <code>{status}</code>\n\n"

                    # Tambahkan tombol berwujud nomor saja (data tetap memuat username agar sistem tahu)
                    number_buttons.append(Button.inline(str(nomor), data=f"detail_cf:{user}"))
            except: continue

    msg += "▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬"
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page + 1}/{total_pages}"

    # Gabungkan baris tombol angka ke dalam layout utama
    if number_buttons:
        buttons.append(number_buttons)

    # Tombol Navigasi Bawah
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"show_pg:{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"show_pg:{page+1}"))

    if nav_buttons: buttons.append(nav_buttons)
    buttons.append([Button.inline("🔙 Kembali", "ssh")])

    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.respond(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Akses Ditolak", alert=True)
        return
    await render_show_menu(event, 0)

@bot.on(events.CallbackQuery(pattern=b'show_pg:(\d+)'))
async def show_ssh_paginate(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    try:
        page = int(event.data.decode().split(':')[1])
        await render_show_menu(event, page)
    except: await event.answer("Error Pagination")

@bot.on(events.CallbackQuery(pattern=b'detail_cf:(.*)'))
async def detail_ssh_confirm(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true": return
    user = event.data.decode().split(':')[1]

    msg_load = await event.edit("<b>🔄 Mengambil Detail Data...</b>", parse_mode='html')
    try:
        detail_msg = get_full_user_detail(user)
        await msg_load.edit(detail_msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali ke List", "show-ssh")]])
    except Exception as e:
        await msg_load.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "show-ssh")]])

# =================================================================
# 5. SUPER PARSER (Hybrid/Adaptive untuk Script Lama & Baru)
# =================================================================
def parse_monitor_data(text):
    user_data = []
    current_user = {}
    
    # 1. BERSINKAN ANSI & BORDER TABEL BAWAAN BASH
    clean_text = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]', '', text)
    clean_text = re.sub(r'\[\d+(?:;\d+)*[a-zA-Z]', '', clean_text)
    clean_text = re.sub(r'[│┌└├╭╰╮╯╔╚║╠╣─═┐┤┘╗╝╖╜╢╟><]', '', clean_text)
    
    clean_text = clean_text.replace('\r', '\n')
    clean_text = re.sub(r' +', ' ', clean_text)
    
    # 2. ISOLASI BLOK DAFTAR USER
    if "DAFTAR USER ONLINE" in clean_text.upper():
        clean_text = re.split(r'(?i)DAFTAR USER ONLINE', clean_text)[-1]
        
    # 3. EKSTRAKSI DATA DINAMIS
    for line in clean_text.splitlines():
        line = line.strip()
        if not line: continue
        
        if ":" in line:
            parts = line.split(":", 1)
            raw_key = parts[0].strip().lower()
            key = re.sub(r'[^a-z ]', '', raw_key).strip()
            val = parts[1].strip()
            
            # Standarisasi Key 
            std_key = None
            if key in ["user", "username", "akun"]: std_key = "user"
            elif key in ["pass", "password"]: std_key = "pw"
            elif key in ["expired", "exp"]: std_key = "exp"
            elif key in ["usage", "data usage"]: std_key = "usage"
            elif key in ["status"]: std_key = "status"
            elif key in ["tipe vpn", "tipe"]: std_key = "tipe"
            elif key in ["ip address", "ip"]: std_key = "ip"
            elif key in ["proses lgn", "login", "jml login", "port masuk"]: 
                if key != "port masuk": std_key = "login"
            
            if not std_key: continue
            
            # Deteksi User Baru: Jika field sudah ada di memori, push ke array
            if std_key in current_user:
                user_data.append(current_user)
                current_user = {}
                
            if std_key == "login":
                match = re.search(r'^(\d+)', val)
                current_user["login"] = match.group(1) if match else val
            else:
                current_user[std_key] = val

    if current_user:
        user_data.append(current_user)
        
    return user_data

# =================================================================
# RENDER MONITOR (Smart Adaptive UI)
# =================================================================
def render_monitor_page(user_data, page, item_per_page=5):
    total_items = len(user_data)
    total_pages = math.ceil(total_items / item_per_page)
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = user_data[start:end]
    
    msg = f"<b>☁️ TRAFFIC MONITOR SSH & VPN</b>\n"
    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user online saat ini.</i>\n\n"
    else:
        for u in sliced_data:
            user = u.get('user', '-').strip()
            usage = u.get('usage', '0 B').strip()
            
            # BERSINKAN STATUS SECARA TUNTAS
            raw_st = u.get("status", "ACTIVE").strip()
            clean_st = re.sub(r'[🟢🔴]', '', raw_st).strip()
            clean_st = re.sub(r'(?i)(udp|zivpn|mode|/)', '', clean_st).strip()
            
            # Jika status kosong atau tersisa spasi, paksa jadi ONLINE
            if not clean_st or len(clean_st) < 2: 
                clean_st = "ONLINE"
                
            is_expired = "expired" in u.get('exp', '').lower()
            icon_st = "🔴" if is_expired else "🟢"
            
            msg += f"<b>👤 User :</b> <code>{user}</code>\n"
            
            # TAMPILAN DINAMIS: Hanya muncul jika data dikirim dari VPS
            if 'ip' in u:
                msg += f"<b>🌐 IP   :</b> <code>{u['ip']}</code>\n"
            if 'tipe' in u:
                msg += f"<b>🛡️ Tipe :</b> <code>{u['tipe']}</code>\n"
            if 'login' in u:
                msg += f"<b>📱 Login:</b> <code>{u['login']} Device</code>\n"
            if 'pw' in u:
                msg += f"<b>🔑 Pass :</b> <code>{u['pw']}</code>\n"
            if 'exp' in u:
                msg += f"<b>📅 Exp  :</b> <code>{u['exp']}</code>\n"
                
            msg += f"<b>📊 Usage:</b> <code>{usage}</code>\n"
            msg += f"<b>💎 Stat :</b> {icon_st} <code>{clean_st}</code>\n"
            msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n"
            
    display_page = page + 1 if total_pages > 0 else 0
    msg += f"📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    
    return msg, total_pages, page

async def run_login_monitor(event, page=0):
    possible_paths = [
        '/usr/local/sbin/cekssh',
        '/usr/bin/kyt/shell/bot-login-monitor ',
        '/usr/bin/cekssh',
        'cekssh'
    ]
    
    cmd = None
    for path in possible_paths:
        if os.path.exists(path):
            cmd = path
            break

    try: msg_wait = await event.edit("<b>🔄 Scanning Network...</b>\n<i>Mohon tunggu sebentar...</i>", parse_mode='html')
    except: msg_wait = await event.respond("<b>🔄 Scanning Network...</b>\n<i>Mohon tunggu sebentar...</i>", parse_mode='html')
    
    try:
        if not cmd:
            return await msg_wait.edit("❌ <b>Error:</b> Script bash monitor tidak ditemukan.", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
        
        process = subprocess.run(
            f"echo '' | {cmd}", 
            shell=True, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.STDOUT, 
            timeout=20
        )
        raw_output = process.stdout.decode("utf-8", errors="ignore")
        
        user_list = parse_monitor_data(raw_output)
        
        if not user_list and len(raw_output) > 50: 
            if "ONLINE" in raw_output.upper() or "DAFTAR USER" in raw_output.upper() or "DATABASE MEMBER" in raw_output.upper() or "User" in raw_output:
                # Pembersihan teks mentah (Debug Fallback)
                clean_raw = re.sub(r'\x1b\[[0-9;]*[a-zA-Z]|\[\d+(?:;\d+)*[a-zA-Z]|[│┌└├╭╰╮╯╔╚║╠╣─═┐┤┘╗╝╖╜╢╟><]', '', raw_output).replace('\r', '\n')
                clean_raw = re.sub(r'\n\s*\n', '\n', clean_raw) 
                
                debug_msg = f"⚠️ <b>DATA MENTAH (DEBUG MODE)</b>\n\n<b>Monitor Traffic:</b>\n<pre>{clean_raw[:3500]}</pre>"
                await msg_wait.edit(debug_msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
                return

        if not raw_output.strip():
             return await msg_wait.edit("⚠️ <b>Script bash mengembalikan teks kosong!</b>\nCoba jalankan manual di VPS.", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

        final_msg, total_pages, current_page = render_monitor_page(user_list, page, item_per_page=5)
        
        nav_buttons = []
        if current_page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"loginPage_{current_page-1}"))
        if current_page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"loginPage_{current_page+1}"))
        
        buttons = []
        if nav_buttons: buttons.append(nav_buttons)
        buttons.append([Button.inline("🔄 Refresh (Live)", data=f"loginPage_{current_page}"), Button.inline("🔙 Kembali", "ssh")])
        
        await msg_wait.edit(final_msg, buttons=buttons, parse_mode='html')
        
    except subprocess.TimeoutExpired:
        await msg_wait.edit("<b>❌ Error:</b> Proses scanning terlalu lama (Timeout).", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])
    except Exception as e:
        await msg_wait.edit(f"<b>❌ Error System:</b>\n<code>{str(e)}</code>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "ssh")]])

@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    await run_login_monitor(event, page=0)

@bot.on(events.CallbackQuery(pattern=b'loginPage_(\d+)'))
async def paginate_login(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
    try: page = int(event.data.decode().split('_')[1])
    except: page = 0
    await run_login_monitor(event, page=page)

# =================================================================
# 6. MENU UTAMA SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("Access Denied", alert=True)
        return
        
    try:
        inline = [
            [Button.inline("☁️ TRIAL SSH ","trial-ssh"), Button.inline("⚡ CREATE SSH ","create-ssh")],
            [Button.inline("🗑️ DELETE SSH ","delete-ssh"), Button.inline("🔐 CHECK LOGIN","login-ssh")],
            [Button.inline("📊 LIST USER SSH ","show-ssh")],
            [Button.inline("‹ Main Menu ›","menu")]
        ]
        try:
             isp = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()
             country = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('country', 'Unknown'))\"", shell=True).decode("utf-8").strip()
        except:
             isp = "Unknown"
             country = "Unknown"

        msg = f"""
<b>☁️ SSH MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{DOMAIN}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
<b>🌍 Region/City    :</b> <code>{country}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error: {str(e)}")