from kyt import *
import subprocess
import asyncio
import math
import time
import random
import requests
import datetime as DT
import os
from telethon.tl.custom import Button
from telethon import events
from telethon.errors import AlreadyInConversationError

# =================================================================
# FUNGSI PEMBANTU (HELPER)
# =================================================================
def get_ssh_data():
    """Mengambil data raw dari script shell"""
    try:
        cmd = '/usr/bin/kyt/shell/bot/bot-member-ssh'
        if not os.path.exists(cmd):
            cmd = 'bot-member-ssh'
            
        raw_output = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
        data_list = [line for line in raw_output.splitlines() if line.strip()]
        return data_list
    except:
        return []

def render_page(data_list, page, item_per_page=10):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    msg = f"""
<b>👑 LIST MEMBER PREMIUM SSH</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user SSH aktif.</i>\n"
    else:
        for row in sliced_data:
            try:
                parts = row.split("|")
                if len(parts) >= 3:
                    user = parts[0]
                    exp = parts[1]
                    status = parts[2]
                    icon_stat = "🟢" if "UNLOCKED" in status else "🔴"
                    msg += f"""
👤 <b>User   :</b> <code>{user}</code>
📅 <b>Exp    :</b> <code>{exp}</code>
{icon_stat} <b>Status :</b> <code>{status}</code>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
"""
                else: continue
            except: continue

    display_page = page + 1 if total_pages > 0 else 0
    msg += f"📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {display_page}/{total_pages}"
    return msg, total_pages

def get_vps_ip():
    try:
        return subprocess.check_output("curl -sS ipv4.icanhazip.com", shell=True).decode("utf-8").strip()
    except:
        return "Unknown"

# --- FUNGSI PINTAR UNTUK TANYA JAWAB + TOMBOL INLINE BATAL ---
async def ask_input(convo, event, sender_id, prompt):
    # Munculkan pesan dengan tombol Inline Batal di bawahnya
    msg = await convo.send_message(prompt, buttons=[[Button.inline("❌ Batal", data=b"cancel_process_btn")]])
    
    # Tunggu balasan chat ATAU klik tombol batal (diperbaiki di sini)
    t_txt = asyncio.create_task(convo.wait_event(events.NewMessage(incoming=True, from_users=sender_id)))
    t_btn = asyncio.create_task(convo.wait_event(events.CallbackQuery(data=b"cancel_process_btn")))
    
    try:
        done, pending = await asyncio.wait([t_txt, t_btn], return_when=asyncio.FIRST_COMPLETED)
        for p in pending: p.cancel()
        res = done.pop().result()
    except asyncio.TimeoutError:
        await msg.delete()
        raise # Lempar error timeout ke fungsi utama
        
    await msg.delete() # Hapus pesan pertanyaan agar chat tetap bersih
    
    # Deteksi jika yang diklik adalah tombol atau diketik /cancel
    if hasattr(res, 'data') or (hasattr(res, 'raw_text') and res.raw_text.lower() == '/cancel'):
        if hasattr(res, 'data'):
            await res.answer("Membatalkan Proses...") # Stop loading animasi di tombol
        await event.client.send_message(event.chat_id, "❌ **Proses Dibatalkan.**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
        return None
        
    return res.raw_text


# =================================================================
# 1. CREATE SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()
    
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Akses Ditolak!", alert=True)
        return

    async def create_ssh_process():
        try:
            async with bot.conversation(chat, timeout=120) as convo:
                user = await ask_input(convo, event, sender.id, "📝 **Input Username:**")
                if user is None: return
                
                pw = await ask_input(convo, event, sender.id, "🔑 **Input Password:**")
                if pw is None: return
                
                limit = await ask_input(convo, event, sender.id, "📱 **Input Max Login/IP Limit:**\n`Contoh: 2`")
                if limit is None: return

                quota = await ask_input(convo, event, sender.id, "📈 **Input Quota (GB):**\n`Contoh: 10`")
                if quota is None: return
                
                exp = await ask_input(convo, event, sender.id, "⏳ **Input Masa Aktif (Hari):**\n`Contoh: 30`")
                if exp is None: return
        
            msg_load = await event.respond("⚙️ `Processing SSH Account...`")
            
            # --- LOGIC UTAMA ---
            cmd_sys = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{user}:{pw}" | chpasswd && echo "{user} hard maxlogins {limit}" >> /etc/security/limits.conf'
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                
                exp_db = later.strftime("%d %b, %Y")
                created_date = today.strftime("%d %b %Y")
                expired_date = later.strftime("%d %b %Y")
                ip_vps = get_vps_ip()

                db_entry = f"#ssh# {user.strip()} {pw.strip()} {quota.strip()} {limit.strip()} {exp_db}\n"
                try:
                    with open("/etc/ssh/.ssh.db", "a") as db_file:
                        db_file.write(db_entry)
                except Exception as e:
                    print(f"Error writing to db: {e}")

                txt_content = f"""---------------------------------------------------
HOKAGE LEGEND TUNNELING
---------------------------------------------------
Format SSH OVPN Account
---------------------------------------------------
Username         : {user.strip()}
Password         : {pw.strip()}
---------------------------------------------------
IP               : {ip_vps}
Host             : {DOMAIN}
Port OpenSSH     : 443, 80, 22
Port Dropbear    : 443, 109
Port Dropbear WS : 443, 109
Port SSH UDP     : 1-65535
Port SSH WS      : 80, 8080, 8081-9999
Port SSH SSL WS  : 443
Port SSL/TLS     : 400-900
Port OVPN WS SSL : 443
Port OVPN SSL    : 443
Port OVPN TCP    : 443, 1194
Port OVPN UDP    : 2200
BadVPN UDP       : 7100, 7300, 7300
---------------------------------------------------
Aktif Selama     : {exp} Hari
Dibuat Pada      : {created_date}
Berakhir Pada    : {expired_date}
---------------------------------------------------
Payload WSS: GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf] 
---------------------------------------------------
OVPN Download : https://{DOMAIN}:81/
---------------------------------------------------"""
                try:
                    os.makedirs("/var/www/html", exist_ok=True)
                    with open(f"/var/www/html/ssh-{user.strip()}.txt", "w") as f:
                        f.write(txt_content)
                except:
                    pass

            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("⚠️ **User Already Exist / Error System**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
            else:
                msg = f"""
<b>✨ PREMIUM ACCOUNT CREATED ✨</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username :</b> <code>{user.strip()}</code>
🔑 <b>Password :</b> <code>{pw.strip()}</code>
📈 <b>Quota    :</b> <code>{quota.strip()} GB</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 <b>IP VPS   :</b> <code>{ip_vps}</code>
🏢 <b>Host     :</b> <code>{DOMAIN}</code>

<b>⚙️ PORT SETTINGS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
🛡 <b>OpenSSH      :</b> <code>443, 80, 22</code>
🛡 <b>Dropbear     :</b> <code>443, 109</code>
🛡 <b>SSH WS       :</b> <code>80, 8080, 8081-9999</code>
🛡 <b>SSH UDP      :</b> <code>1-65535</code>
🔒 <b>SSH SSL WS   :</b> <code>443</code>
🔒 <b>SSL/TLS      :</b> <code>400-900</code>
🔒 <b>OVPN WS SSL  :</b> <code>443</code>
🔒 <b>OVPN SSL     :</b> <code>443</code>
🔒 <b>OVPN TCP     :</b> <code>443, 1194</code>
🚀 <b>OVPN UDP     :</b> <code>2200</code>
🚀 <b>BadVPN UDP   :</b> <code>7100, 7300, 7300</code>

<b>🔗 FORMAT & PAYLOAD</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>Payload WSS:</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>OVPN Config :</b> https://{DOMAIN}:81/
<b>Save Link   :</b> https://{DOMAIN}:81/ssh-{user.strip()}.txt

<b>📊 ACCOUNT DETAILS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⏳ <b>Aktif Selama :</b> <code>{exp} Hari</code>
📅 <b>Dibuat Pada  :</b> <code>{created_date}</code>
⌛ <b>Berakhir     :</b> <code>{expired_date}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Main Menu", "menu")]])

        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain berjalan!", alert=True)
        except asyncio.TimeoutError:
            await event.respond("⌛ **Waktu Habis.**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`", buttons=[[Button.inline("🔙 Main Menu", "menu")]])

    await create_ssh_process()

# =================================================================
# 2. DELETE SSH (TAMPILAN LIST DENGAN NOMOR & DETAIL)
# =================================================================
def render_delete_list(page, item_per_page=5):
    # Mengambil data dari script shell (format: user|exp|status)
    data_list = get_ssh_data()
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)

    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]

    msg = f"<b>🗑 PILIH USER UNTUK DIHAPUS</b>\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    buttons = []
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user SSH.</i>"
    else:
        for i, row in enumerate(sliced_data):
            try:
                parts = row.split("|")
                user = parts[0].strip()
                exp = parts[1].strip()
                status = parts[2].strip()
                
                # Tampilkan detail per user
                msg += f"<b>{start + i + 1}.</b> <code>{user}</code> | 📅 {exp} | {'🟢' if 'UNLOCKED' in status else '🔴'}\n"
                
                # Buat tombol angka untuk menghapus
                buttons.append(Button.inline(f"{start + i + 1}", data=f"delUser_{user}".encode('utf-8')))
            except: continue

    # Susun tombol angka (misal 5 per baris)
    final_buttons = [buttons[i:i+5] for i in range(0, len(buttons), 5)]

    # Navigasi Pagination
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"delSshPage_{page-1}".encode('utf-8')))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"delSshPage_{page+1}".encode('utf-8')))
    if nav_buttons: final_buttons.append(nav_buttons)

    final_buttons.append([Button.inline("🔙 Kembali", b"ssh")])
    
    msg += f"\n📊 <b>Total:</b> {total_items} | 📄 <b>Page:</b> {page + 1}/{total_pages if total_pages > 0 else 1}"
    return msg, final_buttons

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
    msg, buttons = render_delete_list(0)
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'delSshPage_(\d+)'))
async def paginate_delete_ssh(event):
    page = int(event.data.decode().split('_')[1])
    msg, buttons = render_delete_list(page)
    await event.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'delUser_(.+)'))
async def execute_delete_ssh(event):
    user = event.data.decode().split('_')[1]
    
    # Konfirmasi sebelum hapus (Opsional, langsung hapus agar praktis)
    await event.edit(f"⚙️ `Menghapus user: {user}...`")
    
    cmd = f'userdel -f {user}'
    try:
        subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT)
        subprocess.run(f'sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf', shell=True)
        subprocess.run(f"sed -i '/^#ssh# {user} /d' /etc/ssh/.ssh.db", shell=True)
        subprocess.run(f'rm -f /var/www/html/ssh-{user}.txt', shell=True)
        
        await event.edit(f"✅ User <code>{user}</code> berhasil dihapus!", parse_mode='html', buttons=[
            [Button.inline("🔙 Kembali ke List", b"delete-ssh")],
            [Button.inline("🔙 Menu Utama", b"ssh")]
        ])
    except Exception as e:
        await event.edit(f"❌ Error: {str(e)}", buttons=[[Button.inline("🔙 Kembali", b"delete-ssh")]])

# =================================================================
# 3. TRIAL SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
    chat = event.chat_id
    sender = await event.get_sender()

    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Akses Ditolak!", alert=True)
        return

    async def trial_ssh_process():
        try:
            async with bot.conversation(chat, timeout=60) as convo:
                exp = await ask_input(convo, event, sender.id, "⏱ **Input Masa Aktif (Menit):**\n`Contoh: 30`")
                if exp is None: return
                
                if not exp.isdigit():
                     await event.respond("⚠️ **Error:** Harap masukkan angka saja.", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
                     return

            user = "trialX"+str(random.randint(100,1000))
            pw = "1"
            
            msg_load = await event.respond("⚙️ `Creating Trial SSH...`")
            
            cmd_sys = f"""
            useradd -s /bin/false -M {user} && \\
            echo "{user}:{pw}" | chpasswd && \\
            mkdir -p /etc/kyt/limit/ssh/ip && \\
            echo "1" > /etc/kyt/limit/ssh/ip/{user} && \\
            sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf && \\
            echo "{user} hard maxlogins 1" >> /etc/security/limits.conf && \\
            
            (
                sleep {exp}m
                
                killall -9 -u "{user}" 2>/dev/null
                pkill -9 -u "{user}" 2>/dev/null
                sleep 2
                userdel -f "{user}" 2>/dev/null
                
                sed -i "/^{user} hard maxlogins/d" /etc/security/limits.conf 2>/dev/null
                rm -f /etc/kyt/limit/ssh/ip/{user} 2>/dev/null
                sed -i "/\\b{user}\\b/d" /etc/ssh/.ssh.db 2>/dev/null
                
                if [ -f /etc/zivpn/config.json ]; then
                    jq 'del(.auth.config[] | select(. == "{user}"))' /etc/zivpn/config.json > /tmp/zivpn_{user}.tmp && mv /tmp/zivpn_{user}.tmp /etc/zivpn/config.json
                    systemctl restart zivpn 2>/dev/null
                fi
            ) >/dev/null 2>&1 &
            """
            
            try:
                subprocess.check_output(cmd_sys, shell=True, stderr=subprocess.STDOUT)
                
                today = DT.date.today()
                created_date = today.strftime("%d %b %Y")
                
                db_exp_date = (today + DT.timedelta(days=1)).strftime("%d %b, %Y")
                db_entry = f"#ssh# {user} {pw} 1 1 {db_exp_date}\n"
                try:
                    with open("/etc/ssh/.ssh.db", "a") as db_file:
                        db_file.write(db_entry)
                except:
                    pass

                ip_vps = get_vps_ip()

            except subprocess.CalledProcessError:
                await msg_load.delete()
                await event.respond("⚠️ **Failed to create trial.**", buttons=[[Button.inline("🔙 Main Menu", "menu")]])
            else:
                msg = f"""
<b>✨ TRIAL ACCOUNT CREATED ✨</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
👤 <b>Username :</b> <code>{user.strip()}</code>
🔑 <b>Password :</b> <code>{pw.strip()}</code>
📈 <b>Quota    :</b> <code>1 GB</code>
🔒 <b>Limit IP :</b> <code>1 Device</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 <b>IP VPS   :</b> <code>{ip_vps}</code>
🏢 <b>Host     :</b> <code>{DOMAIN}</code>

<b>⚙️ PORT SETTINGS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
🛡 <b>OpenSSH      :</b> <code>443, 80, 22</code>
🛡 <b>Dropbear     :</b> <code>443, 109</code>
🛡 <b>SSH WS       :</b> <code>80, 8080, 8081-9999</code>
🛡 <b>SSH UDP      :</b> <code>1-65535</code>
🔒 <b>SSH SSL WS   :</b> <code>443</code>
🔒 <b>SSL/TLS      :</b> <code>400-900</code>
🔒 <b>OVPN WS SSL  :</b> <code>443</code>
🔒 <b>OVPN SSL     :</b> <code>443</code>
🔒 <b>OVPN TCP     :</b> <code>443, 1194</code>
🚀 <b>OVPN UDP     :</b> <code>2200</code>
🚀 <b>BadVPN UDP   :</b> <code>7100, 7300, 7300</code>

<b>🔗 FORMAT & PAYLOAD</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>Payload WSS:</b>
<code>GET wss://BUG.COM/ HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]</code>

<b>OVPN Config :</b> https://{DOMAIN}:81/

<b>📊 ACCOUNT DETAILS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
⏳ <b>Aktif Selama :</b> <code>{exp} Menit</code>
📅 <b>Dibuat Pada  :</b> <code>{created_date}</code>
⚠️ <i>Akun otomatis diputus & dihapus saat waktu habis.</i>
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Main Menu", "menu")]])
        
        except AlreadyInConversationError:
            await event.answer("⚠️ Sedang ada proses lain berjalan!", alert=True)
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`", buttons=[[Button.inline("🔙 Main Menu", "menu")]])

    await trial_ssh_process()

# =================================================================
# 4. SHOW SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return

    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, 0)
    
    buttons = []
    if total_pages > 1:
        buttons.append([Button.inline("Next ⏩", data=f"sshPage_1")])
    
    # PERUBAHAN DI SINI: Mengubah "menu" menjadi b"ssh"
    buttons.append([Button.inline("🔙 Kembali", b"ssh")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.reply(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b'sshPage_(\d+)'))
async def paginate_ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return

    try: page = int(event.data.decode().split('_')[1])
    except: page = 0
    
    data_list = get_ssh_data()
    msg, total_pages = render_page(data_list, page)
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"sshPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"sshPage_{page+1}"))
    
    buttons = []
    if nav_buttons: buttons.append(nav_buttons)
    
    # PERUBAHAN DI SINI: Mengubah "menu" menjadi b"ssh"
    buttons.append([Button.inline("🔙 Kembali", b"ssh")])
    
    try: await event.edit(msg, buttons=buttons, parse_mode='html')
    except: await event.answer("ℹ️ Halaman tidak berubah")

# =================================================================
# 5. LOGIN SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
    async def login_ssh_(event):
        try:
            cmd = 'bot-cek-login-ssh'.strip()
            z = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")
            
            if len(z) > 4000:
                nama_file = "login_ssh.txt"
                with open(nama_file, "w") as f:
                    f.write(z)
                await event.client.send_file(
                    event.chat_id,
                    nama_file,
                    caption="⚠️ **List Login Terlalu Panjang!**",
                    buttons=[[Button.inline("🔙 Kembali", b"ssh")]] # Diubah ke b"ssh"
                )
                os.remove(nama_file)
            else:
                await event.respond(f"{z}\n🔍 **Check Login SSH**", buttons=[[Button.inline("🔙 Kembali", b"ssh")]]) # Diubah ke b"ssh"
        except Exception as e:
            await event.respond(f"❌ **Error:** `{str(e)}`")

    sender = await event.get_sender()
    if valid(str(sender.id)) == "true":
        await login_ssh_(event)
    else:
        await event.answer("⚠️ Access Denied", alert=True)
# =================================================================
# 7. REGIS IP (USER LICENSE STATUS)
# =================================================================
@bot.on(events.CallbackQuery(data=b'regis'))
async def cek_regis(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return

    msg_load = await event.respond("⚙️ <i>Checking License Status...</i>", parse_mode='html')
    
    try:
        # Ambil IP VPS menggunakan fungsi helper yang sudah ada
        my_ip = get_vps_ip()
        if not my_ip or my_ip == "Unknown":
            # Fallback jika get_vps_ip gagal
            my_ip = subprocess.check_output("curl -s4 ipv4.icanhazip.com", shell=True).decode("utf-8").strip()
            
        # ==============================================================
        # MENGGUNAKAN LINK ASLI DARI SCRIPT VPS ANDA
        # ==============================================================
        url = "https://raw.githubusercontent.com/hokagelegend9999/ijin/refs/heads/main/alpha"
        
        # Tarik data murni menggunakan Python (Tanpa Bash sama sekali)
        resp = requests.get(url, timeout=10)
        data_mentah = resp.text.splitlines()
        
        ditemukan = False
        for baris in data_mentah:
            if my_ip in baris:
                parts = baris.split()
                if len(parts) >= 3: # Format di GitHub: IP USERNAME EXPIRED
                    c_user = parts[1]
                    c_exp = parts[2]
                    # Jika ada kolom ke-4, ambil sebagai IP terdaftar. Jika tidak, pakai MYIP.
                    c_reg = parts[3] if len(parts) >= 4 else my_ip
                    ditemukan = True
                    break
        
        if not ditemukan:
            msg = f"""
<b>❌ LICENSE NOT FOUND</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
IP VPS <code>{my_ip}</code> belum terdaftar.

<i>💡 Tips: Pastikan IP VPS sudah didaftarkan di GitHub.</i>
"""
        else:
            # Hitung sisa hari menggunakan fungsi waktu murni Python
            today = DT.date.today()
            try:
                # Ubah teks tanggal (YYYY-MM-DD) jadi format Date Python
                exp_date = DT.datetime.strptime(c_exp, "%Y-%m-%d").date()
                sisa_hari = (exp_date - today).days
            except:
                sisa_hari = 0
                
            sts = "Active" if sisa_hari >= 0 else "Expired"
            icon_sts = "🟢" if sts == "Active" else "🔴"
            
            msg = f"""
<b>👑 USER LICENSE STATUS 👑</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 <b>IP VPS     :</b> <code>{my_ip}</code>
👤 <b>Username   :</b> <code>{c_user}</code>
📝 <b>Registered :</b> <code>{c_reg}</code>
📅 <b>Expired    :</b> <code>{c_exp}</code>
⏳ <b>Validity   :</b> <code>{sisa_hari} Days</code>
{icon_sts} <b>Status     :</b> <code>{sts}</code>
━━━━━━━━━━━━━━━━━━━━━━━━━━
"""

        await msg_load.delete()
        await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali", b"ssh")]])
        
    except Exception as e:
        await msg_load.delete()
        err_text = str(e).replace('<', '&lt;').replace('>', '&gt;')
        await event.respond(f"<b>❌ System Error:</b>\n<code>{err_text}</code>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", b"ssh")]])
# =================================================================
# 6. MENU UTAMA SSH
# =================================================================
@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        await event.answer("⚠️ Access Denied", alert=True)
        return
        
    try:
        inline = [
            [Button.inline("⏱ TRIAL SSH", "trial-ssh"), Button.inline("✨ CREATE SSH", "create-ssh")],
            [Button.inline("🗑 DELETE SSH", "delete-ssh"), Button.inline("🔍 CHECK LOGIN", "login-ssh")],
            [Button.inline("👥 SHOW USERS", "show-ssh"), Button.inline("📝 REGIS IP", "regis")],
            [Button.inline("🔙 Main Menu", "menu")]
        ]
        try:
             isp = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('isp', 'Unknown'))\"", shell=True).decode("utf-8").strip()
             country = subprocess.check_output("curl --max-time 2 -s http://ip-api.com/json | python3 -c \"import sys, json; print(json.load(sys.stdin).get('country', 'Unknown'))\"", shell=True).decode("utf-8").strip()
        except:
             isp = "Unknown"
             country = "Unknown"

        msg = f"""
<b>👑 HOKAGE PREMIUM TUNNELING 👑</b>
━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ <b>SSH & OVPN MANAGEMENT MENU</b> ⚡
━━━━━━━━━━━━━━━━━━━━━━━━━━

📌 <b>System Information:</b>
🖥 <b>Service  :</b> <code>SSH & OVPN</code>
🌐 <b>Hostname :</b> <code>{DOMAIN}</code>
🏢 <b>ISP      :</b> <code>{isp}</code>
🌍 <b>Country  :</b> <code>{country}</code>

👨‍💻 <b>Dev :</b> @HookageLegend
━━━━━━━━━━━━━━━━━━━━━━━━━━
<i>Silakan pilih opsi manajemen di bawah ini:</i>
"""
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"❌ Error: {str(e)}")