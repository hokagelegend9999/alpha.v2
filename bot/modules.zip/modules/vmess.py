# =================================================================
# FULL VMESS MANAGER (HOKAGE LEGEND PREMIUM)
# =================================================================
from kyt import * # Import bot dari sistem utama Anda
from telethon import events, Button
from telethon.errors import AlreadyInConversationError
import subprocess
import asyncio
import math
import re
import json
import base64
import requests
import datetime as DT
import os

# =================================================================
# GLOBAL STATE & CANCEL HANDLER
# =================================================================
if 'active_convs' not in globals():
    active_convs = {}

@bot.on(events.CallbackQuery(data=b'cancel_process'))
async def cancel_process_handler(event):
    chat = event.chat_id
    if chat in active_convs:
        active_convs[chat].cancel()
        del active_convs[chat]
    await event.edit("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# =================================================================
# ENGINE: DATA EXTRACTION & XRAY API
# =================================================================
def get_vmess_data():
    """Membaca daftar user statis dari config.json (Super Cepat)"""
    try:
        cmd = 'grep -E "^### " "/etc/xray/config.json"'
        raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        data_list = []
        seen_users = set()
        
        for line in raw_output.splitlines():
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    user, exp = parts[1], parts[2]
                    if user not in seen_users:
                        data_list.append({"user": user, "exp": exp})
                        seen_users.add(user)
        return data_list
    except:
        return []

def dict_to_b64(d):
    """Helper untuk encode dictionary ke JSON string -> Base64"""
    json_str = json.dumps(d, separators=(',', ':'))
    return base64.b64encode(json_str.encode('utf-8')).decode('utf-8')

def get_vmess_realtime_details(user):
    """Membaca Realtime Log IP & Traffic Kuota API Xray (Port 10000)"""
    ip_count = 0
    status_icon, status_text = "🔴", "Offline"
    
    # 1. Cek Online Status & IP Terhubung
    try:
        log_cmd = f"cat /var/log/xray/access.log | grep -w '{user}' | tail -n 500"
        log_output = subprocess.check_output(log_cmd, shell=True).decode("utf-8")
        if log_output.strip():
            ip_cmd = f"echo '{log_output}' | cut -d ' ' -f 3 | sed 's/tcp://g' | cut -d ':' -f 1 | sort | uniq | wc -l"
            ip_count = int(subprocess.check_output(ip_cmd, shell=True).decode("utf-8").strip())
            if ip_count > 0:
                status_icon, status_text = "🟢", "Online"
    except: pass

    # 2. Cek IP Limit Database
    iplimit = "Unlimited"
    try:
        if os.path.exists(f"/etc/kyt/limit/vmess/ip/{user}"):
            with open(f"/etc/kyt/limit/vmess/ip/{user}", "r") as f:
                val = f.read().strip()
                if val and val != "0": iplimit = val
    except: pass
    
    ip_login_str = f"{ip_count} / {iplimit} IP"
    if iplimit != "Unlimited" and ip_count > int(iplimit):
        ip_login_str += " ⚠️ OVERLIMIT"

    # 3. Cek Quota Limit Database
    quota_limit_str = "Unlimited"
    try:
        if os.path.exists(f"/etc/vmess/{user}"): # Diperbaiki lokasi file default kuota vmess
            with open(f"/etc/vmess/{user}", "r") as f:
                q_val = f.read().strip()
                if q_val and q_val != "0":
                    b = int(q_val)
                    if b < 1048576: quota_limit_str = f"{(b + 1023)//1024} KB"
                    elif b < 1073741824: quota_limit_str = f"{(b + 1048575)//1048576} MB"
                    else: quota_limit_str = f"{(b + 1073741823)//1073741824} GB"
    except: pass

    # 4. Cek Real Usage via Xray API (DENGAN PENYEMBUNYI ERROR 2>/dev/null)
    usage_str = "0 B"
    try:
        dl_cmd = f'xray api stats --server=127.0.0.1:10000 -name "user>>>{user}>>>traffic>>>downlink" 2>/dev/null | grep "value" | awk \'{{print $2}}\' | sed "s/[\\",]//g"'
        ul_cmd = f'xray api stats --server=127.0.0.1:10000 -name "user>>>{user}>>>traffic>>>uplink" 2>/dev/null | grep "value" | awk \'{{print $2}}\' | sed "s/[\\",]//g"'
        
        dl_str = subprocess.check_output(dl_cmd, shell=True).decode("utf-8").strip()
        ul_str = subprocess.check_output(ul_cmd, shell=True).decode("utf-8").strip()
        
        total_bytes = (int(dl_str) if dl_str else 0) + (int(ul_str) if ul_str else 0)
        if total_bytes > 0:
            if total_bytes < 1048576: usage_str = f"{(total_bytes + 1023)//1024} KB"
            elif total_bytes < 1073741824: usage_str = f"{(total_bytes + 1048575)//1048576} MB"
            else: usage_str = f"{(total_bytes + 1073741823)//1073741824} GB"
    except: pass

    return status_icon, status_text, ip_login_str, f"{usage_str} / {quota_limit_str}"

# =================================================================
# UI RENDERING (LIST & DELETE - TANPA API)
# =================================================================
def render_page_content(data_list, page, mode="list", item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    sliced_data = data_list[start:start + item_per_page]
    
    title = "⚡ LIST USER VMESS" if mode == "list" else "🗑️ DELETE USER VMESS"
    msg = f"<b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    number_buttons = []
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VMess terdaftar.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            user, exp = row["user"], row["exp"]
            nomor = start + i + 1
            try:
                diff = (DT.datetime.strptime(exp, "%Y-%m-%d").date() - DT.date.today()).days
                exp_status = f"🟢 Active ({diff} Hari)" if diff >= 0 else f"🔴 Expired ({abs(diff)}d)"
            except: 
                exp_status = "⚪ Unlimited"

            msg += f"<b>{nomor}. User :</b> <code>{user}</code>\n   ├ 📅 Exp  : <code>{exp}</code>\n   └ 💎 Stat : {exp_status}\n\n"
            
            # Tombol Horizontal (List = 🔍, Delete = ❌)
            cb_data = f"vDetail_{user}_{page}" if mode == "list" else f"delExec_{user}_{page}"
            icon = "🔍 Detail" if mode == "list" else "❌ Hapus"
            number_buttons.append(Button.inline(f"{icon} {nomor}", data=cb_data))

    if mode == "delete" and sliced_data: 
        msg += "<i>Klik tombol di bawah untuk menghapus:</i>\n"
        
    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"

    # Pembagian Tombol agar rapi
    all_buttons = []
    row_btns = []
    for btn in number_buttons:
        row_btns.append(btn)
        if len(row_btns) == 3: # Max 3 tombol di hapus/list sebaris
            all_buttons.append(row_btns)
            row_btns = []
    if row_btns: all_buttons.append(row_btns)
    
    nav_buttons = []
    cb_pref = "vmessPage_" if mode == "list" else "delPage_"
    
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"{cb_pref}{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"{cb_pref}{page+1}"))
    
    if nav_buttons: all_buttons.append(nav_buttons)
    all_buttons.append([Button.inline("🔙 Kembali", "vmess")])
    
    return msg, total_pages, all_buttons

# =================================================================
# UI RENDERING (CHECK LOGIN - DENGAN API REALTIME)
# =================================================================
def render_login_monitor_vmess(data_list, page, item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    sliced_data = data_list[start:start + item_per_page]
    
    msg = f"<b>☁️ MONITOR VMESS USER UTAMA</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VMess.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            user, exp = row["user"], row["exp"]
            nomor = start + i + 1
            
            icon, status_txt, ip_info, quota_info = get_vmess_realtime_details(user)
            
            try:
                diff = (DT.datetime.strptime(exp, "%Y-%m-%d").date() - DT.date.today()).days
                exp_status = f"{diff} Hari" if diff >= 0 else f"Expired ({abs(diff)}d)"
            except: 
                exp_status = "Unlimited"

            msg += f"""<b>{nomor}. User :</b> <code>{user}</code>
   ├ 📅 Exp  : <code>{exp}</code> ({exp_status})
   ├ 📊 Data : <code>{quota_info}</code>
   ├ 📱 Login: <code>{ip_info}</code>
   └ 💎 Stat : {icon} <code>{status_txt}</code>\n\n"""

    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vloginPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vloginPage_{page+1}"))
    
    buttons = [nav_buttons] if nav_buttons else []
    buttons.append([Button.inline("🔄 Refresh", data=f"vloginPage_{page}"), Button.inline("🔙 Kembali", "vmess")])
    return msg, buttons


# =================================================================
# MENU UTAMA VMESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'vmess'))
async def vmess_menu(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Access Denied", alert=True)
    except: pass

    try:
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,isp", timeout=2).json()
            isp, country = z.get("isp", "Unknown"), z.get("country", "Unknown")
        except:
            isp, country = "Unknown", "Unknown"
        
        try: my_domain = DOMAIN
        except: my_domain = "Premium Server"

        msg = f"""
<b>⚡ VMESS MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{my_domain}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
<b>🌍 Region/City    :</b> <code>{country}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        inline = [
            [Button.inline("⚡ TRIAL", "trial-vmess"), Button.inline("⚡ CREATE", "create-vmess")],
            [Button.inline("🗑️ DELETE", "delete-vmess"), Button.inline("🔐 CHECK LOGIN", "login-vmess")],
            [Button.inline("📊 LIST USER", "list-vmess")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error Menu: {str(e)}")

# =================================================================
# CREATE VMESS (CONVERSATION)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-vmess'))
async def create_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass

    async def create_vmess_process(event):
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv
                
                # 1. Username
                p_msg = await event.respond('<b>👤 Input Username:</b>', parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await p_msg.edit("❌ <b>Dibatalkan.</b>", buttons=[[Button.inline("‹ Kembali ›", "vmess")]], parse_mode='html')
                user = ev.raw_text.strip()
                await p_msg.edit(buttons=None)
            
                # 2. Quota
                p_msg = await event.respond("<b>💾 Input Quota (GB):</b>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await p_msg.edit("❌ <b>Dibatalkan.</b>", buttons=[[Button.inline("‹ Kembali ›", "vmess")]], parse_mode='html')
                quota = ev.raw_text.strip()
                await p_msg.edit(buttons=None)

                # 3. IP Limit
                p_msg = await event.respond("<b>📱 Input IP Limit (Angka):</b>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await p_msg.edit("❌ <b>Dibatalkan.</b>", buttons=[[Button.inline("‹ Kembali ›", "vmess")]], parse_mode='html')
                iplimit = ev.raw_text.strip()
                await p_msg.edit(buttons=None)
            
                # 4. Expired
                p_msg = await event.respond("<b>📅 Input Expired (Hari):</b>", parse_mode='html', buttons=cancel_btn)
                ev = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ev.raw_text.lower() or 'batal' in ev.raw_text.lower():
                    return await p_msg.edit("❌ <b>Dibatalkan.</b>", buttons=[[Button.inline("‹ Kembali ›", "vmess")]], parse_mode='html')
                exp = ev.raw_text.strip()
                await p_msg.edit(buttons=None)

            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>Processing...</code>", parse_mode='html')
            
            # Memanggil script backend asli Anda untuk insert
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{iplimit}" | addws-bot'
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vmess://(.*)", a)]
                if not links: raise Exception("Link tidak ditemukan atau User sudah ada")
                
                z = base64.b64decode(links[0].replace("vmess://","")).decode("ascii")
                d = json.loads(z)
                
                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else ""
                link_grpc = links[2].strip() if len(links) > 2 else "" 
                
                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                
                msg = f"""<b>✅ VMESS PREMIUM CREATED</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username  :</b> <code>{d.get("ps", user)}</code>
<b>🌐 Domain    :</b> <code>{d.get("add", DOMAIN)}</code>
<b>💾 Quota     :</b> <code>{quota} GB</code>
<b>📱 IP Limit  :</b> <code>{iplimit} IP</code>
<b>📅 Expired   :</b> <code>{later}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINKS</b>
<b>🔮 TLS  :</b> <code>{link_tls}</code>

<b>🔮 NTLS :</b> <code>{link_ntls}</code>

<b>🔮 GRPC :</b> <code>{link_grpc}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "vmess")]])
            except Exception as e:
                await msg_load.delete()
                await event.respond(f"<b>❌ Error:</b> Pastikan User belum ada di database. ({str(e)})", buttons=[[Button.inline("‹ Kembali ›", "vmess")]], parse_mode='html')
                
        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Selesaikan/batalkan proses sebelumnya.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis (Timeout)</b>", parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error System:</b> {str(e)}", parse_mode='html')

    await create_vmess_process(event)

# =================================================================
# TRIAL VMESS (CONVERSATION)
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-vmess'))
async def trial_vmess(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass

    async def trial_vmess_process(event):
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv
                p_msg = await event.respond("<b>⏱️ Input Durasi Trial (Menit):</b>", parse_mode='html', buttons=cancel_btn)
                resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                
                if '/cancel' in resp.raw_text.lower() or 'batal' in resp.raw_text.lower():
                    return await p_msg.edit("❌ <b>Dibatalkan.</b>", buttons=[[Button.inline("‹ Kembali ›", "vmess")]], parse_mode='html')
                exp = resp.raw_text.strip()
                await p_msg.edit(buttons=None)
                
                if not exp.isdigit():
                    active_convs.pop(chat, None)
                    return await event.respond("<b>❌ Error:</b> Masukkan angka saja.", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "vmess")]])
            
            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>Creating Trial...</code>", parse_mode='html')
            
            cmd = f'printf "%s\n" "{exp}" | bot-trialws'
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vmess://(.*)", a)]
                if not links: raise Exception("Gagal generate link")

                z = base64.b64decode(links[0].replace("vmess://","")).decode("ascii")
                d = json.loads(z)

                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else ""
                link_grpc = links[2].strip() if len(links) > 2 else ""

                msg = f"""<b>✅ VMESS TRIAL CREATED</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username  :</b> <code>{d.get("ps", "Trial")}</code>
<b>⏳ Expired   :</b> <code>{exp} Menit</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINKS</b>
<b>🔮 TLS  :</b> <code>{link_tls}</code>

<b>🔮 NTLS :</b> <code>{link_ntls}</code>

<b>🔮 GRPC :</b> <code>{link_grpc}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "vmess")]])
            except Exception as e: 
                await msg_load.delete()
                await event.respond(f"❌ <b>Gagal:</b> {e}", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "vmess")]])
                
        except asyncio.CancelledError: return
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis</b>", parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"Error: {e}")

    await trial_vmess_process(event)

# =================================================================
# HANDLERS (LIST, DELETE, LOGIN, DETAIL)
# =================================================================

# --- 1. LIST VMESS ---
@bot.on(events.CallbackQuery(data=b'list-vmess'))
async def list_vmess_handler(event):
    data_list = get_vmess_data()
    msg, total_pages, all_buttons = render_page_content(data_list, 0, mode="list")
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vmessPage_(\d+)"))
async def paginate_vmess(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vmess_data()
    msg, total_pages, all_buttons = render_page_content(data_list, page, mode="list")
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

# --- 2. DELETE VMESS ---
@bot.on(events.CallbackQuery(data=b'delete-vmess'))
async def delete_vmess(event):
    data_list = get_vmess_data()
    msg, total_pages, all_buttons = render_page_content(data_list, 0, mode="delete")
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"delPage_(\d+)"))
async def paginate_delete_vmess(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vmess_data()
    msg, total_pages, all_buttons = render_page_content(data_list, page, mode="delete")
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"delExec_(.+)_(.+)"))
async def delete_vmess_exec(event):
    try:
        user = event.pattern_match.group(1).decode()
        page = int(event.pattern_match.group(2).decode())
    except: return
    
    await event.answer(f"⏳ Menghapus user: {user}...", alert=False)
    
    # Hapus via Regex langsung dari Python agar tidak bergantung bot-delws
    try:
        user_safe = user.replace('/', '\/')
        subprocess.run(f"sed -i '/^### {user_safe} /,/^}},{{/d' /etc/xray/config.json", shell=True)
        subprocess.run(f"sed -i '/\\b{user}\\b/d' /etc/vmess/.vmess.db 2>/dev/null", shell=True)
        subprocess.run(f"rm -f /etc/vmess/{user} /etc/xray/{user}-tls.json /etc/kyt/limit/vmess/ip/{user} /var/www/html/vmess-{user}.txt 2>/dev/null", shell=True)
        subprocess.run("systemctl restart xray", shell=True)
        
        await event.answer(f"✅ User {user} Berhasil Dihapus!", alert=True)
        
        data_list = get_vmess_data()
        msg, total_pages, all_buttons = render_page_content(data_list, page, mode="delete")
        await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except Exception as e:
        await event.answer(f"❌ Gagal menghapus: {str(e)}", alert=True)

# --- 3. CHECK LOGIN VMESS ---
@bot.on(events.CallbackQuery(data=b'login-vmess'))
async def login_vmess_handler(event):
    msg_wait = await event.edit("<b>🔄 Scanning Network & Xray API...</b>\n<i>Mohon tunggu...</i>", parse_mode='html')
    data_list = get_vmess_data()
    msg, buttons = render_login_monitor_vmess(data_list, 0)
    await msg_wait.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vloginPage_(\d+)"))
async def paginate_login_vmess(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    msg_wait = await event.edit("<b>🔄 Refreshing Live Data...</b>", parse_mode='html')
    data_list = get_vmess_data()
    msg, buttons = render_login_monitor_vmess(data_list, page)
    await msg_wait.edit(msg, buttons=buttons, parse_mode='html')

# --- 4. DETAIL VMESS (VIEW CONFIG) ---
@bot.on(events.CallbackQuery(pattern=b"vDetail_(.+)_(.+)"))
async def detail_vmess(event):
    try:
        user = event.pattern_match.group(1).decode()
        page_origin = event.pattern_match.group(2).decode()
    except: return
    
    msg_wait = await event.edit("<b>🔄 Membangun Link VMess...</b>", parse_mode='html')
    
    try:
        # PERBAIKAN 1: Pencarian UUID yang jauh lebih akurat
        uuid_cmd = f"grep -wE '^### {user}' -A 5 /etc/xray/config.json | grep '\"id\"' | awk -F '\"' '{{print $4}}' | head -n 1"
        try:
            uuid = subprocess.check_output(uuid_cmd, shell=True).decode("utf-8").strip()
        except subprocess.CalledProcessError:
            uuid = ""
        
        # PERBAIKAN 2: Jika UUID tetap kosong, gunakan metode alternatif
        if not uuid:
            alt_uuid_cmd = f"grep -E '^}},{{' /etc/xray/config.json | grep -i '\"{user}\"' | cut -d ' ' -f 2 | cut -d '\"' -f 2 | head -n 1"
            try:
                uuid = subprocess.check_output(alt_uuid_cmd, shell=True).decode("utf-8").strip()
            except:
                uuid = ""

        if not uuid:
            return await msg_wait.edit(f"❌ <b>Gagal:</b> User <code>{user}</code> tidak ditemukan di config.json.", buttons=[[Button.inline("🔙 Kembali", data=f"vmessPage_{page_origin}")]], parse_mode='html')

        exp_cmd = f"grep -wE '^### {user}' /etc/xray/config.json | cut -d ' ' -f 3 | head -n 1"
        try:
            exp = subprocess.check_output(exp_cmd, shell=True).decode("utf-8").strip()
        except:
            exp = "Unknown"
        
        try: 
            iplimit = subprocess.check_output(f"cat /etc/kyt/limit/vmess/ip/{user}", shell=True).decode("utf-8").strip()
        except: 
            iplimit = "Unknown"
        
        try:
            quota_bytes = int(subprocess.check_output(f"cat /etc/vmess/{user}", shell=True).decode("utf-8").strip())
            quota = f"{quota_bytes // 1073741824} GB"
        except: 
            quota = "Unknown"

        # Build JSON Configuration for Link
        try: domain = DOMAIN
        except: domain = "Premium Server"

        dict_tls = {"v": "2", "ps": user, "add": domain, "port": "443", "id": uuid, "aid": "0", "scy": "auto", "net": "ws", "path": "/vmess", "type": "none", "host": domain, "tls": "tls"}
        dict_ntls = {"v": "2", "ps": user, "add": domain, "port": "80", "id": uuid, "aid": "0", "scy": "auto", "net": "ws", "path": "/vmess", "type": "none", "host": domain, "tls": "none"}
        dict_grpc = {"v": "2", "ps": user, "add": domain, "port": "443", "id": uuid, "aid": "0", "scy": "auto", "net": "grpc", "path": "vmess-grpc", "type": "none", "host": domain, "tls": "tls"}
        dict_upg = {"v": "2", "ps": user, "add": domain, "port": "443", "id": uuid, "aid": "0", "scy": "auto", "net": "httpupgrade", "path": "/vmess-up", "type": "none", "host": domain, "tls": "tls"}

        vmesslink1 = f"vmess://{dict_to_b64(dict_tls)}"
        vmesslink2 = f"vmess://{dict_to_b64(dict_ntls)}"
        vmesslink3 = f"vmess://{dict_to_b64(dict_grpc)}"
        vmesslink4 = f"vmess://{dict_to_b64(dict_upg)}"
        
        msg = f"""<b>👤 USER DETAILS: {user}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🌐 Domain    :</b> <code>{domain}</code>
<b>💾 Quota     :</b> <code>{quota}</code>
<b>📱 IP Limit  :</b> <code>{iplimit} IP</code>
<b>📅 Expired   :</b> <code>{exp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔑 KEY CONFIGURATION</b>
<b>🆔 UUID      :</b> <code>{uuid}</code>
<b>🛡 AlterId   :</b> <code>0</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINKS</b>
<b>🔮 TLS  :</b> <code>{vmesslink1}</code>

<b>🔮 NTLS :</b> <code>{vmesslink2}</code>

<b>🔮 GRPC :</b> <code>{vmesslink3}</code>

<b>🔮 UPGRADE :</b> <code>{vmesslink4}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
        await msg_wait.edit(msg, buttons=[[Button.inline("🔙 Kembali ke List", data=f"vmessPage_{page_origin}")]], parse_mode='html', link_preview=False)
    except Exception as e:
        await msg_wait.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", data=f"vmessPage_{page_origin}")]])