# =================================================================
# FULL VLESS MANAGER (HOKAGE LEGEND PREMIUM)
# =================================================================
from kyt import * # Import bot dari sistem utama Anda
from telethon import events, Button
from telethon.errors import AlreadyInConversationError
import subprocess
import asyncio
import math
import re
import requests
import datetime as DT
import os

# =================================================================
# GLOBAL STATE & CANCEL HANDLER
# =================================================================
if 'active_convs' not in globals():
    active_convs = {}

@bot.on(events.CallbackQuery(data=b'cancel_process'))
async def cancel_process_handler(event):
    chat = event.chat_id
    if chat in active_convs:
        active_convs[chat].cancel()
        del active_convs[chat]
    await event.edit("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# =================================================================
# ENGINE: DATA EXTRACTION & XRAY API
# =================================================================
def get_vless_data():
    """Mengambil data user VLESS dari config.json (Regex #&)"""
    try:
        cmd = 'grep -E "^#& " "/etc/xray/config.json"'
        raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        data_list = []
        seen_users = set() 
        
        for line in raw_output.splitlines():
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    user = parts[1]
                    exp = parts[2]
                    if user not in seen_users:
                        data_list.append({"user": user, "exp": exp})
                        seen_users.add(user)
        return data_list
    except:
        return []

def get_vless_realtime_details(user):
    """Membaca Realtime Log IP & Traffic Kuota API Xray Khusus VLESS"""
    ip_count = 0
    status_icon, status_text = "🔴", "Offline"
    
    # 1. Cek Online Status & IP Terhubung
    try:
        log_cmd = f"cat /var/log/xray/access.log | grep -w '{user}' | tail -n 500"
        log_output = subprocess.check_output(log_cmd, shell=True).decode("utf-8")
        if log_output.strip():
            ip_cmd = f"echo '{log_output}' | cut -d ' ' -f 3 | sed 's/tcp://g' | cut -d ':' -f 1 | sort | uniq | wc -l"
            ip_count = int(subprocess.check_output(ip_cmd, shell=True).decode("utf-8").strip())
            if ip_count > 0:
                status_icon, status_text = "🟢", "Online"
    except: pass

    # 2. Cek IP Limit Database
    iplimit = "Unlimited"
    try:
        if os.path.exists(f"/etc/kyt/limit/vless/ip/{user}"):
            with open(f"/etc/kyt/limit/vless/ip/{user}", "r") as f:
                val = f.read().strip()
                if val and val != "0": iplimit = val
    except: pass
    
    ip_login_str = f"{ip_count} / {iplimit} IP"
    if iplimit != "Unlimited" and ip_count > int(iplimit):
        ip_login_str += " ⚠️ OVERLIMIT"

    # 3. Cek Quota Limit Database
    quota_limit_str = "Unlimited"
    try:
        if os.path.exists(f"/etc/vless/{user}"):
            with open(f"/etc/vless/{user}", "r") as f:
                q_val = f.read().strip()
                if q_val and q_val != "0":
                    b = int(q_val)
                    if b < 1048576: quota_limit_str = f"{(b + 1023)//1024} KB"
                    elif b < 1073741824: quota_limit_str = f"{(b + 1048575)//1048576} MB"
                    else: quota_limit_str = f"{(b + 1073741823)//1073741824} GB"
    except: pass

    # 4. Cek Real Usage via Xray API
    usage_str = "0 B"
    try:
        dl_cmd = f'xray api stats --server=127.0.0.1:10000 -name "user>>>{user}>>>traffic>>>downlink" 2>/dev/null | grep "value" | awk \'{{print $2}}\' | sed "s/[\\",]//g"'
        ul_cmd = f'xray api stats --server=127.0.0.1:10000 -name "user>>>{user}>>>traffic>>>uplink" 2>/dev/null | grep "value" | awk \'{{print $2}}\' | sed "s/[\\",]//g"'
        
        dl_str = subprocess.check_output(dl_cmd, shell=True).decode("utf-8").strip()
        ul_str = subprocess.check_output(ul_cmd, shell=True).decode("utf-8").strip()
        
        total_bytes = (int(dl_str) if dl_str else 0) + (int(ul_str) if ul_str else 0)
        if total_bytes > 0:
            if total_bytes < 1048576: usage_str = f"{(total_bytes + 1023)//1024} KB"
            elif total_bytes < 1073741824: usage_str = f"{(total_bytes + 1048575)//1048576} MB"
            else: usage_str = f"{(total_bytes + 1073741823)//1073741824} GB"
    except: pass

    return status_icon, status_text, ip_login_str, f"{usage_str} / {quota_limit_str}"

# =================================================================
# UI RENDERING (LIST & DELETE)
# =================================================================
def render_page_content(data_list, page, mode="list", item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    sliced_data = data_list[start:start + item_per_page]
    
    title = "⚡ LIST USER VLESS" if mode == "list" else "🗑️ DELETE USER VLESS"
    msg = f"<b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    number_buttons = []
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VLESS terdaftar.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            user, exp = row["user"], row["exp"]
            nomor = start + i + 1
            try:
                diff = (DT.datetime.strptime(exp, "%Y-%m-%d").date() - DT.date.today()).days
                exp_status = f"🟢 Active ({diff} Hari)" if diff >= 0 else f"🔴 Expired ({abs(diff)}d)"
            except: 
                exp_status = "⚪ Unlimited"

            msg += f"<b>{nomor}. User :</b> <code>{user}</code>\n   ├ 📅 Exp  : <code>{exp}</code>\n   └ 💎 Stat : {exp_status}\n\n"
            
            cb_data = f"vlDetail_{user}_{page}" if mode == "list" else f"vlDelExec_{user}_{page}"
            icon = "🔍 Detail" if mode == "list" else "❌ Hapus"
            number_buttons.append(Button.inline(f"{icon} {nomor}", data=cb_data))

    if mode == "delete" and sliced_data: 
        msg += "<i>Klik tombol di bawah untuk menghapus:</i>\n"
        
    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"

    all_buttons = []
    row_btns = []
    for btn in number_buttons:
        row_btns.append(btn)
        if len(row_btns) == 3:
            all_buttons.append(row_btns)
            row_btns = []
    if row_btns: all_buttons.append(row_btns)
    
    nav_buttons = []
    cb_pref = "vlPage_" if mode == "list" else "vlDelPage_"
    
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"{cb_pref}{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"{cb_pref}{page+1}"))
    
    if nav_buttons: all_buttons.append(nav_buttons)
    all_buttons.append([Button.inline("🔙 Kembali", "vless")])
    
    return msg, total_pages, all_buttons

# =================================================================
# UI RENDERING (CHECK LOGIN VLESS)
# =================================================================
def render_login_monitor_vless(data_list, page, item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    sliced_data = data_list[start:start + item_per_page]
    
    msg = f"<b>☁️ MONITOR VLESS USER UTAMA</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VLESS.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            user, exp = row["user"], row["exp"]
            nomor = start + i + 1
            icon, status_txt, ip_info, quota_info = get_vless_realtime_details(user)
            
            try:
                diff = (DT.datetime.strptime(exp, "%Y-%m-%d").date() - DT.date.today()).days
                exp_status = f"{diff} Hari" if diff >= 0 else f"Expired ({abs(diff)}d)"
            except: 
                exp_status = "Unlimited"

            msg += f"""<b>{nomor}. User :</b> <code>{user}</code>
   ├ 📅 Exp  : <code>{exp}</code> ({exp_status})
   ├ 📊 Data : <code>{quota_info}</code>
   ├ 📱 Login: <code>{ip_info}</code>
   └ 💎 Stat : {icon} <code>{status_txt}</code>\n\n"""

    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlLoginPg_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlLoginPg_{page+1}"))
    
    buttons = [nav_buttons] if nav_buttons else []
    buttons.append([Button.inline("🔄 Refresh", data=f"vlLoginPg_{page}"), Button.inline("🔙 Kembali", "vless")])
    return msg, buttons

# =================================================================
# 1. MENU UTAMA VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless_menu(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Access Denied", alert=True)
    except: pass

    try:
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,isp", timeout=2).json()
            isp, country = z.get("isp", "Unknown"), z.get("country", "Unknown")
        except:
            isp, country = "Unknown", "Unknown"
        
        try: my_domain = DOMAIN
        except: my_domain = "Premium Server"

        msg = f"""
<b>⚡ VLESS MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{my_domain}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
<b>🌍 Region/City    :</b> <code>{country}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        inline = [
            [Button.inline("⚡ TRIAL", "trial-vless"), Button.inline("⚡ CREATE", "create-vless")],
            [Button.inline("📊 LIST USER", "list-vless"), Button.inline("🗑️ DELETE", "delete-vless")],
            [Button.inline("🔐 CHECK LOGIN", "login-vless")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error Menu: {str(e)}")

# =================================================================
# 2. CREATE VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Akses Ditolak", alert=True)
    except: pass

    async def create_vless_process(event):
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            
            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv

                prompt_msg = await event.respond('<b>👤 Input Username:</b>', parse_mode='html', buttons=cancel_btn)
                user_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in user_event.raw_text.lower() or 'batal' in user_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
                user = user_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)
            
                prompt_msg = await event.respond("<b>💾 Input Quota (GB):</b>", parse_mode='html', buttons=cancel_btn)
                quota_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in quota_event.raw_text.lower() or 'batal' in quota_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
                quota = quota_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)

                prompt_msg = await event.respond("<b>📱 Input IP Limit (Angka):</b>", parse_mode='html', buttons=cancel_btn)
                ip_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ip_event.raw_text.lower() or 'batal' in ip_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
                iplimit = ip_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)
            
                prompt_msg = await event.respond("<b>📅 Input Expired (Hari):</b>", parse_mode='html', buttons=cancel_btn)
                exp_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in exp_event.raw_text.lower() or 'batal' in exp_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
                exp = exp_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)

            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>Processing...</code>", parse_mode='html')
            
            # Tetap gunakan addvless-bot untuk penambahan config di VPS
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{iplimit}" | addvless-bot'
            
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vless://(.*)", a)]
                if not links: raise Exception("Link tidak ditemukan (User mungkin sudah ada)")
                
                # Parsing URI VLESS (TIDAK MENGGUNAKAN BASE64 DECODE KARENA INI VLESS)
                main_link = links[0]
                uuid = main_link.split("://")[1].split("@")[0]
                try: domain = main_link.split("@")[1].split(":")[0]
                except: domain = DOMAIN
                
                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else ""
                link_grpc = links[2].strip() if len(links) > 2 else ""
                
                # Membangun link HTTPUPGRADE secara manual
                link_upg = f"vless://{uuid}@{domain}:443?path=/vless-up&security=tls&encryption=none&host={domain}&type=httpupgrade&sni={domain}#{user}"

                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                
                msg = f"""<b>✨ VLESS PREMIUM CREATED ✨</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username  :</b> <code>{user}</code>
<b>🌐 Domain    :</b> <code>{domain}</code>
<b>💾 Quota     :</b> <code>{quota} GB</code>
<b>📱 IP Limit  :</b> <code>{iplimit} IP</code>
<b>📅 Expired   :</b> <code>{later}</code>

<b>⚙️ PORT SETTINGS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
🔒 <b>Port TLS   :</b> <code>400-900, 443</code>
🔓 <b>Port NTLS  :</b> <code>80, 8080, 8880, 2082</code>

<b>🔗 FORMAT & PAYLOAD</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>🔮 TLS  :</b> 
<code>{link_tls}</code>

<b>🔮 NTLS :</b> 
<code>{link_ntls}</code>

<b>🔮 GRPC :</b> 
<code>{link_grpc}</code>

<b>🔮 UPGRADE :</b>
<code>{link_upg}</code>

<b>🌐 OpenClash :</b> https://{domain}:81/vless-{user}.txt
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]], link_preview=False)
            except Exception as e:
                await msg_load.delete()
                await event.respond(f"<b>❌ Error:</b> User exist atau script gagal.\nDetail: {e}", buttons=[[Button.inline("🔙 Kembali", "vless")]], parse_mode='html')

        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Selesaikan/batalkan proses sebelumnya.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis (Timeout)</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error System:</b> {str(e)}", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])

    await create_vless_process(event)

# =================================================================
# 3. TRIAL VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Akses Ditolak", alert=True)
    except: pass

    async def trial_vless_process(event):
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]

            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv
                prompt_msg = await event.respond("<b>⏱️ Input Durasi Trial (Menit):</b>\n<i>Contoh: 30</i>", parse_mode='html', buttons=cancel_btn)
                
                resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in resp.raw_text.lower() or 'batal' in resp.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    return await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
                exp = resp.raw_text.strip()
                await prompt_msg.edit(buttons=None)

                if not exp.isdigit():
                    active_convs.pop(chat, None)
                    return await event.respond("<b>❌ Error:</b> Masukkan angka saja.", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])

            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>Creating Trial...</code>", parse_mode='html')
            
            cmd = f'printf "%s\n" "{exp}" | bot-trialvless'
            
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vless://(.*)", a)]
                if not links: raise Exception("Gagal generate link")
                
                # Parsing URI VLESS
                main_link = links[0]
                uuid = main_link.split("://")[1].split("@")[0]
                try: domain = main_link.split("@")[1].split(":")[0]
                except: domain = DOMAIN
                try: remarks = main_link.split("#")[-1]
                except: remarks = "TrialUser"

                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else ""
                link_grpc = links[2].strip() if len(links) > 2 else ""
                link_upg = f"vless://{uuid}@{domain}:443?path=/vless-up&security=tls&encryption=none&host={domain}&type=httpupgrade&sni={domain}#{remarks}"

                msg = f"""<b>✨ VLESS TRIAL CREATED ✨</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Username  :</b> <code>{remarks}</code>
<b>🌐 Domain    :</b> <code>{domain}</code>
<b>💾 Quota     :</b> <code>1 GB</code>
<b>📱 IP Limit  :</b> <code>1 IP</code>
<b>📅 Expired   :</b> <code>{exp} Menit</code>

<b>⚙️ PORT SETTINGS</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
🔒 <b>Port TLS   :</b> <code>400-900, 443</code>
🔓 <b>Port NTLS  :</b> <code>80, 8080, 8880, 2082</code>

<b>🔗 FORMAT & PAYLOAD</b>
▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰
<b>🔮 TLS  :</b> 
<code>{link_tls}</code>

<b>🔮 NTLS :</b> 
<code>{link_ntls}</code>

<b>🔮 GRPC :</b> 
<code>{link_grpc}</code>

<b>🔮 UPGRADE :</b>
<code>{link_upg}</code>

<b>🌐 OpenClash :</b> https://{domain}:81/vless-{remarks}.txt
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]], link_preview=False)
            except Exception as e: 
                await msg_load.edit(f"❌ Gagal membuat trial. {str(e)}", buttons=[[Button.inline("🔙 Kembali", "vless")]])

        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Selesaikan/batalkan proses sebelumnya.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis (Timeout)</b>", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", "vless")]])
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"Error: {e}", buttons=[[Button.inline("🔙 Kembali", "vless")]])

    await trial_vless_process(event)

# =================================================================
# 4. LIST & PAGINATION VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'list-vless'))
async def list_vless_handler(event):
    data_list = get_vless_data()
    msg, total_pages, all_buttons = render_page_content(data_list, 0, mode="list")
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlPage_(\d+)"))
async def paginate_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vless_data()
    msg, total_pages, all_buttons = render_page_content(data_list, page, mode="list")
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

# =================================================================
# 5. DETAIL VLESS (PURE PYTHON)
# =================================================================
@bot.on(events.CallbackQuery(pattern=b"vlDetail_(.+)_(.+)"))
async def detail_vless(event):
    try:
        user = event.pattern_match.group(1).decode()
        page_origin = event.pattern_match.group(2).decode()
    except: return
    
    msg_wait = await event.edit("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    
    try:
        # Fetch UUID
        uuid_cmd = f"grep -wE '^#& {user}' -A 5 /etc/xray/config.json | grep '\"id\"' | awk -F '\"' '{{print $4}}' | head -n 1"
        try: uuid = subprocess.check_output(uuid_cmd, shell=True).decode("utf-8").strip()
        except: uuid = ""
        
        if not uuid:
            alt_uuid_cmd = f"grep -E '^}},{{' /etc/xray/config.json | grep -i '\"{user}\"' | cut -d ' ' -f 2 | cut -d '\"' -f 2 | head -n 1"
            try: uuid = subprocess.check_output(alt_uuid_cmd, shell=True).decode("utf-8").strip()
            except: uuid = ""

        if not uuid:
            return await msg_wait.edit(f"❌ <b>Gagal:</b> User <code>{user}</code> tidak ditemukan.", buttons=[[Button.inline("🔙 Kembali", data=f"vlPage_{page_origin}")]], parse_mode='html')

        # Fetch Expiry
        exp_cmd = f"grep -wE '^#& {user}' /etc/xray/config.json | cut -d ' ' -f 3 | head -n 1"
        try: exp = subprocess.check_output(exp_cmd, shell=True).decode("utf-8").strip()
        except: exp = "Unknown"
        
        # Fetch Limits
        try:
            if os.path.exists(f"/etc/kyt/limit/vless/ip/{user}"):
                iplimit = subprocess.check_output(f"cat /etc/kyt/limit/vless/ip/{user}", shell=True).decode("utf-8").strip()
            else: iplimit = "Unlimited"
        except: iplimit = "Unlimited"
        
        try:
            if os.path.exists(f"/etc/vless/{user}"):
                quota_bytes = int(subprocess.check_output(f"cat /etc/vless/{user}", shell=True).decode("utf-8").strip())
                quota = "Unlimited" if quota_bytes == 0 else f"{quota_bytes // 1073741824} GB"
            else: quota = "Unlimited"
        except: quota = "Unlimited"

        try: domain = DOMAIN
        except: domain = "Premium Server"

        # Build Links Secara Manual (Karena formatnya URI VLESS)
        link_tls = f"vless://{uuid}@{domain}:443?path=/vless&security=tls&encryption=none&host={domain}&type=ws&sni={domain}#{user}"
        link_ntls = f"vless://{uuid}@{domain}:80?path=/vless&security=none&encryption=none&host={domain}&type=ws#{user}"
        link_grpc = f"vless://{uuid}@{domain}:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc&sni={domain}#{user}"
        link_upg = f"vless://{uuid}@{domain}:443?path=/vless-up&security=tls&encryption=none&host={domain}&type=httpupgrade&sni={domain}#{user}"
        
        msg = f"""<b>👤 USER DETAILS: {user}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🌐 Domain    :</b> <code>{domain}</code>
<b>💾 Quota     :</b> <code>{quota}</code>
<b>📱 IP Limit  :</b> <code>{iplimit} IP</code>
<b>📅 Expired   :</b> <code>{exp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔑 KEY CONFIGURATION</b>
<b>🆔 UUID      :</b> <code>{uuid}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINKS</b>
<b>🔮 TLS  :</b> 
<code>{link_tls}</code>

<b>🔮 NTLS :</b> 
<code>{link_ntls}</code>

<b>🔮 GRPC :</b> 
<code>{link_grpc}</code>

<b>🔮 UPGRADE :</b>
<code>{link_upg}</code>

<b>🌐 OpenClash :</b> https://{domain}:81/vless-{user}.txt
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""
        
        buttons = [[Button.inline("🔙 Kembali ke List", data=f"vlPage_{page_origin}")]]
        await msg_wait.edit(msg, buttons=buttons, parse_mode='html', link_preview=False)
    except Exception as e:
        await msg_wait.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html', buttons=[[Button.inline("🔙 Kembali", data=f"vlPage_{page_origin}")]])

# =================================================================
# 6. DELETE VLESS (PURE PYTHON)
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    data_list = get_vless_data()
    msg, total_pages, del_buttons = render_page_content(data_list, 0, mode="delete")
    try: await event.edit(msg, buttons=del_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=del_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlDelPage_(\d+)"))
async def paginate_delete_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vless_data()
    msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
    try: await event.edit(msg, buttons=del_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"vlDelExec_(.+)_(.+)"))
async def delete_vless_exec(event):
    try:
        user = event.pattern_match.group(1).decode()
        page = int(event.pattern_match.group(2).decode())
    except: return
    
    await event.answer(f"⏳ Menghapus user: {user}...", alert=False)
    
    try:
        # Eksekusi Delete via Python (sed + rm)
        user_safe = user.replace('/', '\/')
        subprocess.run(f"sed -i '/^#& {user_safe} /,/^}},{{/d' /etc/xray/config.json", shell=True)
        subprocess.run(f"sed -i '/\\b{user}\\b/d' /etc/vless/.vless.db 2>/dev/null", shell=True)
        subprocess.run(f"rm -f /etc/vless/{user} /etc/xray/{user}-tls.json /etc/kyt/limit/vless/ip/{user} /var/www/html/vless-{user}.txt 2>/dev/null", shell=True)
        subprocess.run("systemctl restart xray", shell=True)
        
        await event.answer(f"✅ User {user} Berhasil Dihapus!", alert=True)
        
        data_list = get_vless_data()
        msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
        await event.edit(msg, buttons=del_buttons, parse_mode='html')
    except Exception as e:
        await event.answer(f"❌ Gagal menghapus: {str(e)}", alert=True)

# =================================================================
# 7. CHECK LOGIN VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'login-vless'))
async def login_vless_handler(event):
    msg_wait = await event.edit("<b>🔄 Scanning Network & Xray API...</b>\n<i>Mohon tunggu...</i>", parse_mode='html')
    data_list = get_vless_data()
    msg, buttons = render_login_monitor_vless(data_list, 0)
    await msg_wait.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlLoginPg_(\d+)"))
async def paginate_login_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    msg_wait = await event.edit("<b>🔄 Refreshing Live Data...</b>", parse_mode='html')
    data_list = get_vless_data()
    msg, buttons = render_login_monitor_vless(data_list, page)
    await msg_wait.edit(msg, buttons=buttons, parse_mode='html')