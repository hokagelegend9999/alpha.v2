# =================================================================
# FULL TROJAN MANAGER (HOKAGE LEGEND PREMIUM)
# =================================================================
from kyt import * # Import bot dan fungsi valid/auth dari file utama
from telethon import events, Button
from telethon.errors import AlreadyInConversationError
import subprocess
import asyncio
import math
import time
import re
import json
import base64
import requests
import datetime as DT
import os

# =================================================================
# GLOBAL STATE UNTUK CONVERSATION
# =================================================================
if 'active_convs' not in globals():
    active_convs = {}

@bot.on(events.CallbackQuery(data=b'cancel_process'))
async def cancel_process_handler(event):
    chat = event.chat_id
    if chat in active_convs:
        active_convs[chat].cancel()
        del active_convs[chat]
    await event.edit("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "menu")]])

# =================================================================
# FUNGSI PEMBANTU (HELPER) & API XRAY
# =================================================================
def get_trojan_data():
    """Mengambil data user Trojan dari config.json (Regex #!)"""
    try:
        cmd = 'grep -E "^#! " "/etc/xray/config.json"'
        raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        data_list = []
        seen_users = set() 
        
        for line in raw_output.splitlines():
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    user = parts[1]
                    exp = parts[2]
                    if user not in seen_users:
                        data_list.append({"user": user, "exp": exp})
                        seen_users.add(user)
        return data_list
    except:
        return []

def get_trojan_realtime_details(user):
    """Membaca Realtime Log IP & Traffic Kuota API Xray untuk Trojan"""
    ip_count = 0
    status_icon, status_text = "🔴", "Offline"
    
    # 1. Cek Online Status & IP Terhubung
    try:
        log_cmd = f"cat /var/log/xray/access.log | grep -w '{user}' | tail -n 500"
        log_output = subprocess.check_output(log_cmd, shell=True).decode("utf-8")
        if log_output.strip():
            ip_cmd = f"echo '{log_output}' | cut -d ' ' -f 3 | sed 's/tcp://g' | cut -d ':' -f 1 | sort | uniq | wc -l"
            ip_count = int(subprocess.check_output(ip_cmd, shell=True).decode("utf-8").strip())
            if ip_count > 0:
                status_icon, status_text = "🟢", "Online"
    except: pass

    # 2. Cek IP Limit Database
    iplimit = "Unlimited"
    try:
        if os.path.exists(f"/etc/kyt/limit/trojan/ip/{user}"):
            with open(f"/etc/kyt/limit/trojan/ip/{user}", "r") as f:
                val = f.read().strip()
                if val and val != "0": iplimit = val
    except: pass
    
    ip_login_str = f"{ip_count} / {iplimit} IP"
    if iplimit != "Unlimited" and ip_count > int(iplimit):
        ip_login_str += " ⚠️ OVERLIMIT"

    # 3. Cek Quota Limit Database
    quota_limit_str = "Unlimited"
    try:
        if os.path.exists(f"/etc/trojan/{user}"):
            with open(f"/etc/trojan/{user}", "r") as f:
                q_val = f.read().strip()
                if q_val and q_val != "0":
                    b = int(q_val)
                    if b < 1048576: quota_limit_str = f"{(b + 1023)//1024} KB"
                    elif b < 1073741824: quota_limit_str = f"{(b + 1048575)//1048576} MB"
                    else: quota_limit_str = f"{(b + 1073741823)//1073741824} GB"
    except: pass

    # 4. Cek Real Usage via Xray API
    usage_str = "0 B"
    try:
        dl_cmd = f'xray api stats --server=127.0.0.1:10000 -name "user>>>{user}>>>traffic>>>downlink" 2>/dev/null | grep "value" | awk \'{{print $2}}\' | sed "s/[\\",]//g"'
        ul_cmd = f'xray api stats --server=127.0.0.1:10000 -name "user>>>{user}>>>traffic>>>uplink" 2>/dev/null | grep "value" | awk \'{{print $2}}\' | sed "s/[\\",]//g"'
        
        dl_str = subprocess.check_output(dl_cmd, shell=True).decode("utf-8").strip()
        ul_str = subprocess.check_output(ul_cmd, shell=True).decode("utf-8").strip()
        
        total_bytes = (int(dl_str) if dl_str else 0) + (int(ul_str) if ul_str else 0)
        if total_bytes > 0:
            if total_bytes < 1048576: usage_str = f"{(total_bytes + 1023)//1024} KB"
            elif total_bytes < 1073741824: usage_str = f"{(total_bytes + 1048575)//1048576} MB"
            else: usage_str = f"{(total_bytes + 1073741823)//1073741824} GB"
    except: pass

    return status_icon, status_text, ip_login_str, f"{usage_str} / {quota_limit_str}"

# =================================================================
# UI RENDERING
# =================================================================
def render_page_content(data_list, page, mode="list", item_per_page=5):
    """Render Mode List dan Delete Trojan"""
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    title = "⚡ LIST USER TROJAN" if mode == "list" else "🗑️ DELETE USER TROJAN"
    msg = f"<b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    flat_buttons = [] 
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user Trojan.</i>"
    else:
        for row in sliced_data:
            user = row["user"]
            exp = row["exp"]
            
            try:
                today = DT.date.today()
                exp_dt = DT.datetime.strptime(exp, "%Y-%m-%d").date()
                diff = (exp_dt - today).days
                if diff >= 0: status = f"🟢 Active ({diff} Hari)"
                else: status = f"🔴 Expired ({abs(diff)} Hari Lalu)"
            except: status = "⚪ Unlimited"

            msg += f"""<b>👤 User :</b> <code>{user}</code>
<b>📅 Exp  :</b> <code>{exp}</code>
<b>💎 Stat :</b> {status}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
            if mode == "list":
                flat_buttons.append(Button.inline(f"🔍 {user}", data=f"trDetail_{user}_{page}"))
            else:
                flat_buttons.append(Button.inline(f"🗑️ {user}", data=f"trDelExec_{user}_{page}"))

    if mode == "delete" and sliced_data:
        msg += "\n<i>Klik tombol user di bawah untuk menghapus:</i>"
        
    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"

    grid_buttons = [flat_buttons[i:i + 2] for i in range(0, len(flat_buttons), 2)]
    return msg, total_pages, grid_buttons

def render_login_monitor_trojan(data_list, page, item_per_page=5):
    """UI Render untuk Monitor Login Trojan Realtime"""
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    sliced_data = data_list[start:start + item_per_page]
    
    msg = f"<b>☁️ MONITOR TROJAN USER UTAMA</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user Trojan.</i>\n"
    else:
        for i, row in enumerate(sliced_data):
            user, exp = row["user"], row["exp"]
            nomor = start + i + 1
            
            icon, status_txt, ip_info, quota_info = get_trojan_realtime_details(user)
            
            try:
                diff = (DT.datetime.strptime(exp, "%Y-%m-%d").date() - DT.date.today()).days
                exp_status = f"{diff} Hari" if diff >= 0 else f"Expired ({abs(diff)}d)"
            except: 
                exp_status = "Unlimited"

            msg += f"""<b>{nomor}. User :</b> <code>{user}</code>
   ├ 📅 Exp  : <code>{exp}</code> ({exp_status})
   ├ 📊 Data : <code>{quota_info}</code>
   ├ 📱 Login: <code>{ip_info}</code>
   └ 💎 Stat : {icon} <code>{status_txt}</code>\n\n"""

    msg += f"▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"trloginPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"trloginPage_{page+1}"))
    
    buttons = [nav_buttons] if nav_buttons else []
    buttons.append([Button.inline("🔄 Refresh", data=f"trloginPage_{page}"), Button.inline("🔙 Kembali", "trojan")])
    return msg, buttons

# =================================================================
# 1. MENU UTAMA TROJAN
# =================================================================
@bot.on(events.CallbackQuery(data=b'trojan'))
async def trojan_menu(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Access Denied", alert=True)
    except: pass

    try:
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,isp", timeout=2).json()
            isp = z.get("isp", "Unknown")
            country = z.get("country", "Unknown")
        except:
            isp, country = "Unknown", "Unknown"
        
        try: my_domain = DOMAIN
        except: my_domain = "Premium Server"

        msg = f"""
<b>⚡ TROJAN MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{my_domain}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
<b>🌍 Region/City    :</b> <code>{country}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        inline = [
            [Button.inline("⚡ TRIAL", "trial-trojan"), Button.inline("⚡ CREATE", "create-trojan")],
            [Button.inline("🗑️ DELETE", "delete-trojan"), Button.inline("🔐 CHECK LOGIN", "login-trojan")],
            [Button.inline("📊 LIST USER", "list-trojan")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error Menu: {str(e)}")

# =================================================================
# 2. CREATE TROJAN (PREMIUM FULL OUTPUT)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-trojan'))
async def create_trojan(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)
    except: pass

    async def create_trojan_process(event):
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]
            
            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv

                prompt_msg = await event.respond('<b>👤 Input Username:</b>', parse_mode='html', buttons=cancel_btn)
                user_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in user_event.raw_text.lower() or 'batal' in user_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "trojan")]])
                    return
                user = user_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)
            
                prompt_msg = await event.respond("<b>💾 Input Quota (GB):</b>", parse_mode='html', buttons=cancel_btn)
                quota_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in quota_event.raw_text.lower() or 'batal' in quota_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "trojan")]])
                    return
                quota = quota_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)

                prompt_msg = await event.respond("<b>📱 Input IP Limit (Angka):</b>", parse_mode='html', buttons=cancel_btn)
                ip_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in ip_event.raw_text.lower() or 'batal' in ip_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "trojan")]])
                    return
                iplimit = ip_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)
            
                prompt_msg = await event.respond("<b>📅 Input Expired (Hari):</b>", parse_mode='html', buttons=cancel_btn)
                exp_event = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in exp_event.raw_text.lower() or 'batal' in exp_event.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "trojan")]])
                    return
                exp = exp_event.raw_text.strip()
                await prompt_msg.edit(buttons=None)

            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>Processing...</code>", parse_mode='html')
            
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{iplimit}" | addtr-bot'
            
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer(r"trojan://[^\s]+", a)]
                if not links: raise Exception("Link tidak ditemukan atau User sudah ada")
                
                # Mengambil UUID dan Domain
                main_link = links[0]
                uuid = main_link.replace("trojan://", "").split("@")[0]
                try: domain = main_link.split("@")[1].split(":")[0]
                except: domain = DOMAIN
                
                # Ambil Data Lokasi & ISP
                try:
                    z = requests.get("http://ip-api.com/json/?fields=city,isp", timeout=2).json()
                    isp = z.get("isp", "Unknown")
                    city = z.get("city", "Unknown")
                except:
                    isp, city = "Unknown", "Unknown"

                # Merakit Semua Link Secar Presisi
                link_ws   = f"trojan://{uuid}@{domain}:443?path=%2Ftrojan-ws&security=tls&host={domain}&type=ws&sni={domain}#{user}"
                link_grpc = f"trojan://{uuid}@{domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={domain}#{user}"
                link_upg  = f"trojan://{uuid}@{domain}:443?path=%2Ftrojan-up&security=tls&host={domain}&type=httpupgrade&sni={domain}#{user}"
                openclash = f"https://{domain}:81/trojan-{user}.txt"

                today = DT.date.today()
                later = today + DT.timedelta(days=int(exp))
                
                msg = f"""<b>✅ TROJAN PREMIUM CREATED</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Remarks     :</b> <code>{user}</code>
<b>🌐 Domain      :</b> <code>{domain}</code>
<b>💾 User Quota  :</b> <code>{quota} GB</code>
<b>📱 User Ip     :</b> <code>{iplimit} IP</code>
<b>🎯 Port TLS    :</b> <code>443</code>
<b>🔑 Password    :</b> <code>{uuid}</code>
<b>🌍 Locations   :</b> <code>{city}</code>
<b>📡 ISP         :</b> <code>{isp}</code>
<b>🚏 Path WS     :</b> <code>/trojan-ws</code>
<b>🚏 Path UPG    :</b> <code>/trojan-up</code>
<b>🛰 ServiceName :</b> <code>trojan-grpc</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 Link WS TLS :</b> 
<code>{link_ws}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 Link GRPC   :</b> 
<code>{link_grpc}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 Link UPGRADE:</b> 
<code>{link_upg}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>⚙️ OpenClash   :</b> 
{openclash}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>⏳ Expired Date:</b> <code>{later}</code>
<b>⌛ Sisa Aktif  :</b> <code>{exp} Hari Lagi</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""

                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            except Exception as e:
                await msg_load.delete()
                await event.respond(f"<b>❌ Error:</b> User exist atau script gagal.\nDetail: {e}", buttons=[[Button.inline("‹ Kembali ›", "trojan")]], parse_mode='html')
                
        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Sedang ada proses lain! Selesaikan/batalkan dulu.", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis (Timeout)</b>", parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"<b>❌ Error System:</b> {str(e)}", parse_mode='html')

    await create_trojan_process(event)

# =================================================================
# 3. TRIAL TROJAN (PREMIUM FULL OUTPUT)
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-trojan'))
async def trial_trojan(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return await event.answer("Akses Ditolak", alert=True)
    except: pass

    async def trial_trojan_process(event):
        try:
            cancel_btn = [[Button.inline("❌ Batal", data=b"cancel_process")]]

            async with bot.conversation(chat, timeout=60) as conv:
                active_convs[chat] = conv
                prompt_msg = await event.respond("<b>⏱️ Input Durasi Trial (Menit):</b>\n<i>Contoh: 30</i>", parse_mode='html', buttons=cancel_btn)
                
                resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                if '/cancel' in resp.raw_text.lower() or 'batal' in resp.raw_text.lower():
                    await prompt_msg.edit(buttons=None)
                    await event.respond("❌ <b>Proses Dibatalkan.</b>", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "trojan")]])
                    return
                exp = resp.raw_text.strip()
                await prompt_msg.edit(buttons=None)
                
                if not exp.isdigit():
                    active_convs.pop(chat, None)
                    return await event.respond("<b>❌ Error:</b> Masukkan angka saja.", parse_mode='html', buttons=[[Button.inline("‹ Kembali ›", "trojan")]])

            active_convs.pop(chat, None)
            msg_load = await event.respond("<code>Creating Trial...</code>", parse_mode='html')
            
            cmd = f'printf "%s\n" "{exp}" | bot-trialtr'
            
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer(r"trojan://[^\s]+", a)]
                if not links: raise Exception("Gagal generate link trial")
                
                # Mengambil UUID, Domain, dan Remarks
                main_link = links[0]
                uuid = main_link.replace("trojan://", "").split("@")[0]
                try: domain = main_link.split("@")[1].split(":")[0]
                except: domain = DOMAIN
                
                try: remarks = main_link.split("#")[-1]
                except: remarks = f"Trial-{uuid[:5]}"

                # Ambil Data Lokasi & ISP
                try:
                    z = requests.get("http://ip-api.com/json/?fields=city,isp", timeout=2).json()
                    isp = z.get("isp", "Unknown")
                    city = z.get("city", "Unknown")
                except:
                    isp, city = "Unknown", "Unknown"

                # Merakit Semua Link Secar Presisi
                link_ws   = f"trojan://{uuid}@{domain}:443?path=%2Ftrojan-ws&security=tls&host={domain}&type=ws&sni={domain}#{remarks}"
                link_grpc = f"trojan://{uuid}@{domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={domain}#{remarks}"
                link_upg  = f"trojan://{uuid}@{domain}:443?path=%2Ftrojan-up&security=tls&host={domain}&type=httpupgrade&sni={domain}#{remarks}"
                openclash = f"https://{domain}:81/trojan-{remarks}.txt"

                msg = f"""<b>✅ TROJAN TRIAL CREATED</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>👤 Remarks     :</b> <code>{remarks}</code>
<b>🌐 Domain      :</b> <code>{domain}</code>
<b>💾 User Quota  :</b> <code>1 GB</code>
<b>📱 User Ip     :</b> <code>1 IP</code>
<b>🎯 Port TLS    :</b> <code>443</code>
<b>🔑 Password    :</b> <code>{uuid}</code>
<b>🌍 Locations   :</b> <code>{city}</code>
<b>📡 ISP         :</b> <code>{isp}</code>
<b>🚏 Path WS     :</b> <code>/trojan-ws</code>
<b>🚏 Path UPG    :</b> <code>/trojan-up</code>
<b>🛰 ServiceName :</b> <code>trojan-grpc</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 Link WS TLS :</b> 
<code>{link_ws}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 Link GRPC   :</b> 
<code>{link_grpc}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 Link UPGRADE:</b> 
<code>{link_upg}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>⚙️ OpenClash   :</b> 
{openclash}
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>⏳ Expired Date:</b> <code>{exp} Menit</code>
<b>⌛ Sisa Aktif  :</b> <code>{exp} Menit Lagi</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>"""

                await msg_load.delete()
                await event.respond(msg, parse_mode='html', buttons=[[Button.inline("‹ Main Menu ›", "menu")]])
            except Exception as e: 
                await msg_load.edit(f"❌ Gagal membuat trial. {e}", buttons=[[Button.inline("‹ Kembali ›", "trojan")]])

        except asyncio.CancelledError: return
        except AlreadyInConversationError: await event.answer("⚠️ Sedang ada proses lain!", alert=True)
        except asyncio.TimeoutError:
            active_convs.pop(chat, None)
            await event.respond("<b>❌ Waktu Habis (Timeout)</b>", parse_mode='html')
        except Exception as e:
            active_convs.pop(chat, None)
            await event.respond(f"Error: {e}")

    await trial_trojan_process(event)

# =================================================================
# 4. LIST TROJAN
# =================================================================
@bot.on(events.CallbackQuery(data=b'list-trojan'))
async def list_trojan_handler(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass

    data_list = get_trojan_data()
    msg, total_pages, user_buttons = render_page_content(data_list, 0, mode="list")
    
    nav_buttons = []
    if total_pages > 1: nav_buttons.append(Button.inline("Next ⏩", data=f"trPage_1"))
    
    all_buttons = user_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "trojan")]]
    
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"trPage_(\d+)"))
async def paginate_trojan(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    
    data_list = get_trojan_data()
    msg, total_pages, user_buttons = render_page_content(data_list, page, mode="list")
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"trPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"trPage_{page+1}"))
    
    all_buttons = user_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "trojan")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

# =================================================================
# 5. DETAIL TROJAN
# =================================================================
@bot.on(events.CallbackQuery(pattern=b"trDetail_(.+)_(.+)"))
async def detail_trojan(event):
    try:
        user = event.pattern_match.group(1).decode()
        page_origin = event.pattern_match.group(2).decode()
    except: return
    
    try: msg_wait = await event.edit("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    except: msg_wait = await event.respond("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    
    try:
        cmd_path = '/usr/bin/kyt/shell/bot/bot-trojan-detail' 
        if not os.path.exists(cmd_path):
             return await msg_wait.edit(f"❌ Script {cmd_path} tidak ditemukan.", parse_mode='html')

        subprocess.run(f"chmod +x {cmd_path}", shell=True)
        
        cmd = f'{cmd_path} "{user}"'
        process = subprocess.run(cmd, shell=True, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        raw_data = process.stdout.decode("utf-8").strip()
        
        if not raw_data or "Error" in raw_data:
            await msg_wait.edit(f"❌ <b>Gagal:</b> User {user} tidak ditemukan.", buttons=[[Button.inline("‹ Kembali ›", data=f"trPage_{page_origin}")]], parse_mode='html')
            return

        parts = raw_data.split('|')
        if len(parts) < 6:
             return await msg_wait.edit(f"❌ Output Script Format Salah.", buttons=[[Button.inline("‹ Kembali ›", data=f"trPage_{page_origin}")]])

        d_user = parts[0]
        d_domain = parts[1]
        d_uuid = parts[2]
        d_exp = parts[3]
        d_quota = parts[4]
        d_ip = parts[5]
        d_ws = parts[6]
        d_grpc = parts[7] if len(parts) > 7 else "-"
        
        msg = f"""
<b>👤 USER DETAILS: {d_user}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🌐 Domain    :</b> <code>{d_domain}</code>
<b>💾 Quota     :</b> <code>{d_quota}</code>
<b>📱 IP Limit  :</b> <code>{d_ip}</code>
<b>📅 Expired   :</b> <code>{d_exp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINKS</b>
<b>🔮 WS   :</b> <code>{d_ws}</code>

<b>🔮 GRPC :</b> <code>{d_grpc}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>» 👤 Telegram Admin : @HookageLegend</b>
"""
        buttons = [[Button.inline("‹ Kembali ke List ›", data=f"trPage_{page_origin}")]]
        await msg_wait.edit(msg, buttons=buttons, parse_mode='html', link_preview=False)
    except Exception as e:
        await msg_wait.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html')

# =================================================================
# 6. DELETE TROJAN
# =================================================================
@bot.on(events.CallbackQuery(data=b'delete-trojan'))
async def delete_trojan(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass
    
    data_list = get_trojan_data()
    msg, total_pages, del_buttons = render_page_content(data_list, 0, mode="delete")
    
    nav_buttons = []
    if total_pages > 1: nav_buttons.append(Button.inline("Next ⏩", data=f"trDelPage_1"))
        
    all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "trojan")]]
    
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"trDelPage_(\d+)"))
async def paginate_delete_trojan(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    
    data_list = get_trojan_data()
    msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
    
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"trDelPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"trDelPage_{page+1}"))
    
    all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "trojan")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"trDelExec_(.+)_(.+)"))
async def delete_trojan_exec(event):
    try:
        user = event.pattern_match.group(1).decode()
        page = int(event.pattern_match.group(2).decode())
    except: return
    
    await event.answer(f"⏳ Menghapus user: {user}...", alert=False)
    
    cmd = f'printf "%s\n" "{user}" | bot-deltr' 
    try:
        subprocess.check_output(cmd, shell=True)
        await event.answer(f"✅ User {user} Berhasil Dihapus!", alert=True)
        
        data_list = get_trojan_data()
        msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
        
        nav_buttons = []
        if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"trDelPage_{page-1}"))
        if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"trDelPage_{page+1}"))
        
        all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "trojan")]]
        await event.edit(msg, buttons=all_buttons, parse_mode='html')
        
    except Exception as e:
        await event.answer(f"❌ Gagal menghapus: {str(e)}", alert=True)

# =================================================================
# 7. CHECK LOGIN TROJAN
# =================================================================
@bot.on(events.CallbackQuery(data=b'login-trojan'))
async def login_trojan_handler(event):
    msg_wait = await event.edit("<b>🔄 Scanning Network & Xray API...</b>\n<i>Mohon tunggu...</i>", parse_mode='html')
    data_list = get_trojan_data()
    msg, buttons = render_login_monitor_trojan(data_list, 0)
    await msg_wait.edit(msg, buttons=buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"trloginPage_(\d+)"))
async def paginate_login_trojan(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    msg_wait = await event.edit("<b>🔄 Refreshing Live Data...</b>", parse_mode='html')
    data_list = get_trojan_data()
    msg, buttons = render_login_monitor_trojan(data_list, page)
    await msg_wait.edit(msg, buttons=buttons, parse_mode='html')